<?php
require_once "config/db.php";
require_once "config/functions.php";
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit;
}
$role     = $_POST['role'] ?? '';
$username = clean($conn, $_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
if (!in_array($role, ['admin', 'petugas', 'siswa']) || $username === '' || $password === '') {
    $_SESSION['login_error'] = "Lengkapi username dan password.";
    header("Location: login.php?role=$role");
    exit;
}
if ($role === 'siswa') {
    $stmt = mysqli_prepare($conn, "SELECT * FROM siswa WHERE username = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($res);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['role']       = 'siswa';
        $_SESSION['id']         = $user['id_siswa'];
        $_SESSION['nama']       = $user['nama'];
        $_SESSION['nisn']       = $user['nisn'];
        $_SESSION['username']   = $user['username'];
        $_SESSION['login_notif'] = 'success';
        header("Location: siswa/dashboard.php");
        exit;
    }
} else {
    // admin & petugas sama-sama di tabel admin, dibedakan level
    $stmt = mysqli_prepare($conn, "SELECT * FROM admin WHERE username = ? AND level = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "ss", $username, $role);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($res);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['role']     = $role;
        $_SESSION['id']       = $user['id'];
        $_SESSION['nama']     = $user['nama'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['login_notif'] = 'success';
        header("Location: $role/dashboard.php");
        exit;
    }
}
$_SESSION['login_error'] = "Username atau password salah.";
header("Location: login.php?role=$role");
exit;