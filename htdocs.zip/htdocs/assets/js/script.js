// =========================================================
// Script global aplikasi Perpustakaan Sekolah Digital
// =========================================================
// Toggle sidebar di layar kecil (dashboard admin/petugas/siswa)
function toggleSidebar() {
    document.querySelector('.sidebar')?.classList.toggle('show');
}
// ---------------------------------------------------------
// Bunyi notifikasi dashboard admin (dibuat langsung dengan
// Web Audio API, jadi tidak perlu file suara terpisah)
// ---------------------------------------------------------
function playNotifSound() {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const beep = (freq, start, dur) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.value = freq;
            gain.gain.setValueAtTime(0.001, ctx.currentTime + start);
            gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + start + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
            osc.connect(gain).connect(ctx.destination);
            osc.start(ctx.currentTime + start);
            osc.stop(ctx.currentTime + start + dur);
        };
        beep(880, 0, 0.15);
        beep(1174.66, 0.18, 0.2);
    } catch (e) { /* audio tidak didukung, abaikan */ }
}
// Panggil notifikasi begitu halaman dashboard admin selesai dimuat
document.addEventListener('DOMContentLoaded', function () {
    const notifTrigger = document.getElementById('notifSoundTrigger');
    if (notifTrigger) {
        const count = parseInt(notifTrigger.dataset.count || '0', 10);
        if (count > 0) {
            // beri jeda sedikit supaya tidak diblokir kebijakan autoplay browser
            document.body.addEventListener('click', function once() {
                playNotifSound();
                document.body.removeEventListener('click', once);
            }, { once: true });
        }
    }
});
// Konfirmasi hapus data
function confirmDelete(msg) {
    return confirm(msg || 'Yakin ingin menghapus data ini?');
}
// Live search sederhana pada tabel (dipakai di banyak halaman)
function liveSearch(inputId, tableId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    if (!input || !table) return;
    input.addEventListener('keyup', function () {
        const q = this.value.toLowerCase();
        table.querySelectorAll('tbody tr').forEach(row => {
            row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
        });
    });
}
// ---------------------------------------------------------
// Bunyi notifikasi khusus halaman login (sukses / gagal)
// ---------------------------------------------------------
function playLoginSuccessSound() {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const beep = (freq, start, dur) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.value = freq;
            gain.gain.setValueAtTime(0.001, ctx.currentTime + start);
            gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + start + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
            osc.connect(gain).connect(ctx.destination);
            osc.start(ctx.currentTime + start);
            osc.stop(ctx.currentTime + start + dur);
        };
        beep(523.25, 0, 0.12);    // C5
        beep(659.25, 0.1, 0.12);  // E5
        beep(783.99, 0.2, 0.2);   // G5 (nada naik = ceria)
    } catch (e) { /* audio tidak didukung, abaikan */ }
}

function playLoginErrorSound() {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const beep = (freq, start, dur) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.value = freq;
            gain.gain.setValueAtTime(0.001, ctx.currentTime + start);
            gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + start + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
            osc.connect(gain).connect(ctx.destination);
            osc.start(ctx.currentTime + start);
            osc.stop(ctx.currentTime + start + dur);
        };
        beep(392.00, 0, 0.15);    // G4
        beep(261.63, 0.13, 0.25); // C4 (nada turun = gagal)
    } catch (e) { /* audio tidak didukung, abaikan */ }
}

// Trigger otomatis berdasarkan atribut data-login-notif di <body>
document.addEventListener('DOMContentLoaded', function () {
    const notifType = document.body?.dataset?.loginNotif;
    if (notifType === 'success' || notifType === 'error') {
        const play = notifType === 'success' ? playLoginSuccessSound : playLoginErrorSound;
        document.body.addEventListener('click', function once() {
            play();
            document.body.removeEventListener('click', once);
        }, { once: true });
    }
});