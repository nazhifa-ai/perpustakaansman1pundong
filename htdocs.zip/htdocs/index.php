<?php
require_once "config/db.php";
require_once "config/functions.php";

// ==== ENDPOINT AJAX: ambil daftar komentar ulasan (tanpa perlu login) ====
// Dipanggil oleh JavaScript lewat index.php?ajax_ulasan=1&id_buku=X
if (isset($_GET['ajax_ulasan'])) {
    header('Content-Type: application/json');
    $id_buku = (int) ($_GET['id_buku'] ?? 0);
    $list = [];
    if ($id_buku > 0) {
        $stmt = mysqli_prepare($conn, "
          SELECT s.nama, u.rating, u.komentar, u.tanggal
          FROM ulasan u
          JOIN siswa s ON s.id_siswa = u.id_siswa
          WHERE u.id_buku = ?
          ORDER BY u.tanggal DESC
        ");
        mysqli_stmt_bind_param($stmt, "i", $id_buku);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($row = mysqli_fetch_assoc($res)) {
            $list[] = [
                'nama'     => $row['nama'],
                'rating'   => (int) $row['rating'],
                'komentar' => $row['komentar'],
                'tanggal'  => formatTanggal($row['tanggal']),
            ];
        }
    }
    echo json_encode($list);
    exit;
}
// ==== AKHIR ENDPOINT AJAX ====

$uploadDir = "uploads/buku/";

// Data kategori buku untuk pill list & grafik
$kategoriData = [];
$q = mysqli_query($conn, "SELECT kategori, COUNT(*) AS jml, SUM(buku_tersedia) AS tersedia FROM buku GROUP BY kategori ORDER BY jml DESC");
while ($q && ($row = mysqli_fetch_assoc($q))) {
    $kategoriData[] = $row;
}

// Ambil satu contoh sampul buku (terbaru) untuk tiap kategori
foreach ($kategoriData as $idx => $k) {
    $kat = mysqli_real_escape_string($conn, $k['kategori']);
    $sampulQ = mysqli_query($conn, "SELECT judul_buku, sampul FROM buku WHERE kategori='$kat' AND sampul IS NOT NULL AND sampul != '' ORDER BY id_buku DESC LIMIT 1");
    $sampulRow = $sampulQ ? mysqli_fetch_assoc($sampulQ) : null;
    $kategoriData[$idx]['contoh_sampul'] = $sampulRow['sampul'] ?? null;
    $kategoriData[$idx]['contoh_judul']  = $sampulRow['judul_buku'] ?? null;
}

$totalBuku = 0; $totalTersedia = 0; $totalJudul = 0;
$r = mysqli_query($conn, "SELECT COUNT(*) AS judul, SUM(jumlah) AS total, SUM(buku_tersedia) AS tersedia FROM buku");
if ($r && ($row = mysqli_fetch_assoc($r))) {
    $totalJudul = $row['judul'] ?? 0;
    $totalBuku = $row['total'] ?? 0;
    $totalTersedia = $row['tersedia'] ?? 0;
}

$totalSiswa = 0;
$r2 = mysqli_query($conn, "SELECT COUNT(*) AS c FROM siswa");
if ($r2 && ($row2 = mysqli_fetch_assoc($r2))) $totalSiswa = $row2['c'];

// Buku dengan rating tertinggi
$bukuTerbaik = mysqli_query($conn, "
  SELECT b.id_buku, b.judul_buku, b.penulis, b.sampul, AVG(u.rating) AS rata, COUNT(u.id_ulasan) AS jml
  FROM buku b JOIN ulasan u ON u.id_buku = b.id_buku
  GROUP BY b.id_buku HAVING jml > 0
  ORDER BY rata DESC, jml DESC LIMIT 4
");

$labels = json_encode(array_column($kategoriData, 'kategori'));
$values = json_encode(array_map('intval', array_column($kategoriData, 'jml')));

// Semua buku untuk ditampilkan di section Kategori Buku
$semuaBuku = mysqli_query($conn, "
  SELECT b.id_buku, b.judul_buku, b.penulis, b.kategori, b.sampul,
         COALESCE(AVG(u.rating),0) AS rata, COUNT(u.id_ulasan) AS jml
  FROM buku b LEFT JOIN ulasan u ON u.id_buku = b.id_buku
  GROUP BY b.id_buku
  ORDER BY b.kategori, b.judul_buku
");

$notifUlasan = $_SESSION['ulasan_sukses'] ?? ($_SESSION['ulasan_error'] ?? '');
$notifUlasanTipe = isset($_SESSION['ulasan_sukses']) ? 'success' : 'danger';
unset($_SESSION['ulasan_sukses'], $_SESSION['ulasan_error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Perpustakaan Sekolah Digital</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<style>
.kategori-card {
  background: #fff;
  border: 1px solid #e9ecef;
  border-radius: 14px;
  padding: 16px;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  transition: transform .2s, box-shadow .2s;
}
.kategori-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 10px 24px rgba(0,0,0,.08);
}
.kategori-cover {
  width: 100%;
  height: 170px;
  object-fit: cover;
  border-radius: 10px;
  margin-bottom: 12px;
  background: #f1f3f5;
}
.kategori-cover-placeholder {
  width: 100%;
  height: 170px;
  border-radius: 10px;
  margin-bottom: 12px;
  background: #eef1f6;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #a9b3c1;
  font-size: 2.8rem;
}
.kategori-nama {
  font-weight: 700;
  color: var(--brand-dark, #2653a3);
  margin-bottom: 2px;
}
.kategori-jumlah {
  font-size: .85rem;
  color: #6c757d;
}
.rating-input {
  display: flex;
  flex-direction: row-reverse;
  justify-content: flex-end;
  font-size: 2rem;
}
.rating-input input { display: none; }
.rating-input label {
  color: #dcdcdc;
  cursor: pointer;
  padding: 0 2px;
}
.rating-input input:checked ~ label,
.rating-input label:hover,
.rating-input label:hover ~ label {
  color: #f4a52a;
}
.item-ulasan {
  border-bottom: 1px solid #eee;
  padding: 10px 0;
  text-align: left;
}
.item-ulasan:last-child { border-bottom: none; }

/* ===== Background Hero (Beranda) pakai gambar sendiri ===== */
.hero-section {
  background-image: linear-gradient(rgba(19,41,84,.8), rgba(19,41,84,.8)), url('../img/backrounddpn.jpeg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

/* ===== Tombol & Pop-up WhatsApp Mengambang ===== */
.wa-float-btn {
  position: fixed;
  bottom: 24px;
  right: 24px;
  width: 60px;
  height: 60px;
  background: #25D366;
  color: #fff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30px;
  box-shadow: 0 6px 18px rgba(0,0,0,.25);
  z-index: 1055;
  cursor: pointer;
  border: none;
  animation: waPulse 2.2s infinite;
  transition: transform .2s;
}
.wa-float-btn:hover { transform: scale(1.08); }
@keyframes waPulse {
  0%   { box-shadow: 0 0 0 0 rgba(37,211,102,.55); }
  70%  { box-shadow: 0 0 0 14px rgba(37,211,102,0); }
  100% { box-shadow: 0 0 0 0 rgba(37,211,102,0); }
}
.wa-popup {
  position: fixed;
  bottom: 96px;
  right: 24px;
  width: 300px;
  background: #fff;
  border-radius: 14px;
  box-shadow: 0 12px 30px rgba(0,0,0,.2);
  overflow: hidden;
  z-index: 1055;
  display: none;
  animation: waPopupIn .25s ease-out;
}
.wa-popup.show { display: block; }
@keyframes waPopupIn {
  from { opacity: 0; transform: translateY(12px); }
  to   { opacity: 1; transform: translateY(0); }
}
.wa-popup-header {
  background: #25D366;
  color: #fff;
  padding: 14px 16px;
  display: flex;
  align-items: center;
  gap: 10px;
}
.wa-popup-header i { font-size: 1.5rem; }
.wa-popup-header .wa-title { font-weight: 700; font-size: .95rem; margin: 0; }
.wa-popup-header .wa-sub { font-size: .75rem; opacity: .9; margin: 0; }
.wa-popup-close {
  margin-left: auto;
  background: transparent;
  border: none;
  color: #fff;
  font-size: 1.1rem;
  cursor: pointer;
  line-height: 1;
}
.wa-popup-body {
  padding: 14px 16px;
  font-size: .88rem;
  color: #333;
}
.wa-popup-body p { margin-bottom: 12px; }
.wa-popup-body .btn-success { width: 100%; }
@media (max-width: 480px) {
  .wa-popup { width: calc(100vw - 32px); right: 16px; }
  .wa-float-btn { right: 16px; bottom: 16px; }
}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background: var(--brand-dark);">
  <div class="container">
    <a class="navbar-brand" href="#beranda"><i class="bi bi-book-half"></i> Perpustakaan Digital</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
        <li class="nav-item"><a class="nav-link" href="#beranda">Beranda</a></li>
        <li class="nav-item"><a class="nav-link" href="#kategori">Kategori Buku</a></li>
        <li class="nav-item"><a class="nav-link" href="#favorit">Buku Favorit</a></li>
        <li class="nav-item"><a class="nav-link" href="#grafik">Grafik</a></li>
        <li class="nav-item"><a class="nav-link" href="#fitur">Fitur</a></li>
        <li class="nav-item"><a class="nav-link" href="#jam">Jam Operasional</a></li>
        <li class="nav-item"><a class="nav-link" href="#bantuan">Bantuan</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle btn btn-sm btn-warning text-dark fw-semibold px-3 ms-lg-2" href="#" role="button" data-bs-toggle="dropdown">
            <i class="bi bi-box-arrow-in-right"></i> Masuk
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><h6 class="dropdown-header">Login sebagai</h6></li>
            <li><a class="dropdown-item" href="login.php?role=admin"><i class="bi bi-person-badge me-2"></i>Admin</a></li>
            <li><a class="dropdown-item" href="login.php?role=petugas"><i class="bi bi-person-workspace me-2"></i>Petugas</a></li>
            <li><a class="dropdown-item" href="login.php?role=siswa"><i class="bi bi-mortarboard me-2"></i>Siswa / User</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="hero-section" id="beranda">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-7">
        <span class="badge bg-warning text-dark mb-3">Digitalisasi Perpustakaan Sekolah</span>
        <h1 class="display-5 mb-3">Perpustakaan Sekolah Digital</h1>
        <p class="lead mb-4">Layanan peminjaman dan pendataan buku berbasis web untuk memudahkan seluruh warga sekolah. Cepat, rapi, dan mudah diakses dari komputer sekolah.</p>
        <div class="d-flex flex-wrap gap-3">
          <a href="login.php?role=siswa" class="btn btn-accent btn-lg px-4">Masuk sebagai Siswa</a>
          <a href="#fitur" class="btn btn-outline-light btn-lg px-4">Lihat Fitur</a>
        </div>
      </div>
      <div class="col-lg-5 text-center mt-4 mt-lg-0">
        <i class="bi bi-journal-bookmark-fill" style="font-size: 220px; opacity:.9;"></i>
      </div>
    </div>
  </div>
</section>

<!-- STATISTIK RINGKAS -->
<div class="container">
  <div class="row g-3" style="margin-top:-55px;">
    <div class="col-6 col-md-3">
      <div class="info-card text-center"><h3 class="fw-bold text-primary"><?= $totalJudul ?></h3><small class="text-muted">Judul Buku</small></div>
    </div>
    <div class="col-6 col-md-3">
      <div class="info-card text-center"><h3 class="fw-bold text-primary"><?= $totalBuku ?></h3><small class="text-muted">Total Eksemplar</small></div>
    </div>
    <div class="col-6 col-md-3">
      <div class="info-card text-center"><h3 class="fw-bold text-primary"><?= $totalTersedia ?></h3><small class="text-muted">Buku Tersedia</small></div>
    </div>
    <div class="col-6 col-md-3">
      <div class="info-card text-center"><h3 class="fw-bold text-primary"><?= $totalSiswa ?></h3><small class="text-muted">Anggota Terdaftar</small></div>
    </div>
  </div>
</div>

<!-- FITUR -->
<section class="container py-5 mt-4" id="fitur">
  <h2 class="section-title text-center">Fitur Aplikasi</h2>
  <p class="section-sub text-center">Semua yang dibutuhkan untuk mengelola perpustakaan sekolah dalam satu aplikasi</p>
  <div class="row g-4">
    <div class="col-md-4">
      <div class="feature-card">
        <div class="feature-icon"><i class="bi bi-search"></i></div>
        <h5>Pencarian Buku</h5>
        <p class="text-muted mb-0">Cari buku berdasarkan judul, kategori, atau penulis dengan cepat.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="feature-card">
        <div class="feature-icon"><i class="bi bi-arrow-left-right"></i></div>
        <h5>Peminjaman & Pengembalian</h5>
        <p class="text-muted mb-0">Transaksi peminjaman dan pengembalian buku tercatat secara digital.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="feature-card">
        <div class="feature-icon"><i class="bi bi-bar-chart-line"></i></div>
        <h5>Laporan & Grafik</h5>
        <p class="text-muted mb-0">Statistik koleksi buku dan aktivitas peminjaman secara visual.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="feature-card">
        <div class="feature-icon"><i class="bi bi-person-check"></i></div>
        <h5>Kelola Anggota</h5>
        <p class="text-muted mb-0">Pendataan anggota siswa dan petugas perpustakaan dalam satu sistem.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="feature-card">
        <div class="feature-icon"><i class="bi bi-bell"></i></div>
        <h5>Notifikasi Admin</h5>
        <p class="text-muted mb-0">Pemberitahuan otomatis untuk peminjaman yang terlambat/jatuh tempo.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="feature-card">
        <div class="feature-icon"><i class="bi bi-star"></i></div>
        <h5>Ulasan & Rating</h5>
        <p class="text-muted mb-0">Siswa dapat memberi ulasan dan rating bintang pada buku yang pernah dipinjam.</p>
      </div>
    </div>
  </div>
</section>

<!-- KATEGORI -->
<section class="container py-5" id="kategori">
  <h2 class="section-title text-center">Kategori Buku</h2>
  <p class="section-sub text-center">Koleksi buku perpustakaan beserta ulasan dari siswa</p>

  <?php if ($notifUlasan): ?>
    <div class="alert alert-<?= $notifUlasanTipe ?> text-center"><?= htmlspecialchars($notifUlasan) ?></div>
  <?php endif; ?>

  <?php if (mysqli_num_rows($semuaBuku) === 0): ?>
    <p class="text-muted text-center">Belum ada data buku.</p>
  <?php else: ?>
    <div class="row g-4 justify-content-center">
      <?php while ($buku = mysqli_fetch_assoc($semuaBuku)): ?>
        <div class="col-6 col-md-4 col-lg-3">
          <div class="kategori-card">
            <?php if (!empty($buku['sampul']) && file_exists($uploadDir . $buku['sampul'])): ?>
              <img src="<?= $uploadDir . htmlspecialchars($buku['sampul']) ?>" class="kategori-cover" alt="<?= htmlspecialchars($buku['judul_buku']) ?>">
            <?php else: ?>
              <div class="kategori-cover-placeholder"><i class="bi bi-book"></i></div>
            <?php endif; ?>
            <span class="badge bg-light text-dark border mb-2"><?= htmlspecialchars($buku['kategori']) ?></span>
            <div class="kategori-nama"><?= htmlspecialchars($buku['judul_buku']) ?></div>
            <div class="kategori-jumlah mb-2"><?= htmlspecialchars($buku['penulis']) ?></div>

            <?= renderBintang($buku['rata'], '0.9rem') ?>
            <small class="text-muted d-block mb-2">(<?= $buku['jml'] ?> ulasan)</small>

            <button type="button" class="btn btn-sm btn-outline-secondary w-100 mb-2 btn-lihat-ulasan"
                    data-bs-toggle="modal" data-bs-target="#modalLihatUlasan"
                    data-id="<?= $buku['id_buku'] ?>"
                    data-judul="<?= htmlspecialchars($buku['judul_buku'], ENT_QUOTES) ?>">
              <i class="bi bi-chat-square-text"></i> Lihat Ulasan
            </button>

            <?php if (($_SESSION['role'] ?? '') === 'siswa'): ?>
              <button type="button" class="btn btn-sm btn-outline-primary w-100 btn-ulasan"
                      data-bs-toggle="modal" data-bs-target="#modalUlasan"
                      data-id="<?= $buku['id_buku'] ?>"
                      data-judul="<?= htmlspecialchars($buku['judul_buku'], ENT_QUOTES) ?>">
                <i class="bi bi-star"></i> Beri Ulasan
              </button>
            <?php else: ?>
              <a href="login.php?role=siswa" class="btn btn-sm btn-outline-secondary w-100">
                <i class="bi bi-box-arrow-in-right"></i> Login untuk Ulasan
              </a>
            <?php endif; ?>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  <?php endif; ?>
</section>

<!-- BUKU FAVORIT -->
<section class="container py-5" id="favorit">
  <h2 class="section-title text-center">Buku Favorit Pembaca</h2>
  <p class="section-sub text-center">Dinilai langsung oleh siswa berdasarkan pengalaman membaca</p>
  <div class="row g-4 justify-content-center">
    <?php if (mysqli_num_rows($bukuTerbaik) === 0): ?>
      <p class="text-muted text-center">Belum ada ulasan buku.</p>
    <?php else: while ($bk = mysqli_fetch_assoc($bukuTerbaik)): ?>
      <div class="col-6 col-md-3">
        <div class="kategori-card">
          <?php if (!empty($bk['sampul']) && file_exists($uploadDir . $bk['sampul'])): ?>
            <img src="<?= $uploadDir . htmlspecialchars($bk['sampul']) ?>" class="kategori-cover" alt="<?= htmlspecialchars($bk['judul_buku']) ?>">
          <?php else: ?>
            <div class="kategori-cover-placeholder"><i class="bi bi-book"></i></div>
          <?php endif; ?>
          <div class="kategori-nama"><?= htmlspecialchars($bk['judul_buku']) ?></div>
          <div class="kategori-jumlah mb-1"><?= htmlspecialchars($bk['penulis']) ?></div>
          <?= renderBintang($bk['rata'], '0.9rem') ?>
          <small class="text-muted d-block">(<?= $bk['jml'] ?> ulasan)</small>
        </div>
      </div>
    <?php endwhile; endif; ?>
  </div>
</section>

<!-- GRAFIK -->
<section class="container py-5" id="grafik">
  <h2 class="section-title text-center">Grafik Koleksi Buku</h2>
  <p class="section-sub text-center">Jumlah judul buku pada setiap kategori</p>
  <div class="card-panel">
    <canvas id="chartKategori" height="100"></canvas>
  </div>
</section>

<!-- JAM OPERASIONAL -->
<section class="container py-5" id="jam">
  <h2 class="section-title text-center">Jam Operasional</h2>
  <p class="section-sub text-center">Layanan perpustakaan buka setiap hari kerja</p>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="jam-box">
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="hari">Senin - Jumat</span><span>07.00 - 15.00 WIB</span>
        </div>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <span class="hari">Sabtu - Minggu</span><span class="text-danger fw-semibold">Tutup</span>
        </div>
        <div class="d-flex justify-content-between py-2">
          <span class="hari">Istirahat</span><span>12.00 - 13.00 WIB</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- BANTUAN -->
<section class="container py-5" id="bantuan">
  <h2 class="section-title text-center">Bantuan</h2>
  <p class="section-sub text-center">Pertanyaan yang sering diajukan</p>
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="accordion" id="faqAcc">
        <div class="accordion-item">
          <h2 class="accordion-header"><button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#f1">Bagaimana cara meminjam buku?</button></h2>
          <div id="f1" class="accordion-collapse collapse show" data-bs-parent="#faqAcc">
            <div class="accordion-body">Login sebagai siswa, buka menu <b>Peminjaman</b>, pilih buku yang tersedia, lalu ajukan peminjaman. Buku juga dapat dipinjamkan langsung oleh petugas dengan menunjukkan NIS.</div>
          </div>
        </div>
        <div class="accordion-item">
          <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#f2">Bagaimana jika belum punya akun?</button></h2>
          <div id="f2" class="accordion-collapse collapse" data-bs-parent="#faqAcc">
            <div class="accordion-body">Klik <b>Masuk &rarr; Siswa/User</b>, lalu pilih tautan <b>Daftar Anggota</b> pada halaman login untuk membuat akun baru.</div>
          </div>
        </div>
        <div class="accordion-item">
          <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#f3">Apakah ada denda keterlambatan?</button></h2>
          <div id="f3" class="accordion-collapse collapse" data-bs-parent="#faqAcc">
            <div class="accordion-body">Ya, denda dihitung otomatis oleh sistem sebesar Rp1.000 per hari keterlambatan dari tanggal jatuh tempo.</div>
          </div>
        </div>
        <div class="accordion-item">
          <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#f4">Bagaimana cara memberi ulasan buku?</button></h2>
          <div id="f4" class="accordion-collapse collapse" data-bs-parent="#faqAcc">
            <div class="accordion-body">Login sebagai siswa, buka menu <b>Ulasan Buku</b>. Kamu bisa memberi rating dan komentar pada buku yang pernah kamu pinjam.</div>
          </div>
        </div>
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#f5">
              Butuh bantuan lebih lanjut?
            </button>
          </h2>
          <div id="f5" class="accordion-collapse collapse" data-bs-parent="#faqAcc">
            <div class="accordion-body">
              Kalau pertanyaanmu belum terjawab di atas, hubungi admin perpustakaan langsung lewat WhatsApp.
              <div class="mt-3">
                <a href="https://wa.me/6288221391745?text=Halo%20Admin%20Perpustakaan%2C%20saya%20mau%20bertanya"
                   target="_blank" class="btn btn-success">
                  <i class="bi bi-whatsapp"></i> Chat Admin via WhatsApp
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<footer class="text-center">
  <div class="container">
    <p class="mb-1">&copy; <?= date('Y') ?> Perpustakaan Sekolah Digital &mdash; UKK Rekayasa Perangkat Lunak</p>
    <small>Buka Senin - Jumat, 07.00 - 15.00 WIB</small>
  </div>
</footer>

<!-- ===== TOMBOL & POP-UP WHATSAPP MENGAMBANG (muncul di semua halaman index) ===== -->
<button type="button" class="wa-float-btn" id="waFloatBtn" aria-label="Bantuan via WhatsApp">
  <i class="bi bi-whatsapp"></i>
</button>

<div class="wa-popup" id="waPopup">
  <div class="wa-popup-header">
    <i class="bi bi-whatsapp"></i>
    <div>
      <p class="wa-title">Butuh Bantuan?</p>
      <p class="wa-sub">Admin Perpustakaan Digital</p>
    </div>
    <button type="button" class="wa-popup-close" id="waPopupClose" aria-label="Tutup">&times;</button>
  </div>
  <div class="wa-popup-body">
    <p>Halo! Ada kendala saat meminjam buku, membuat akun, atau pertanyaan lain? Klik tombol di bawah untuk langsung chat admin via WhatsApp.</p>
    <a href="https://wa.me/6288221391745?text=Halo%20Admin%20Perpustakaan%2C%20saya%20mau%20bertanya"
       target="_blank" class="btn btn-success">
      <i class="bi bi-whatsapp"></i> Chat Sekarang
    </a>
  </div>
</div>

<!-- MODAL LIHAT ULASAN (tanpa login) -->
<div class="modal fade" id="modalLihatUlasan" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Ulasan: <span id="lihatJudulBuku"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="lihatUlasanBody" style="max-height:400px; overflow-y:auto;">
        <p class="text-muted text-center">Memuat ulasan...</p>
      </div>
    </div>
  </div>
</div>

<!-- MODAL ULASAN (isi ulasan, khusus siswa login) -->
<div class="modal fade" id="modalUlasan" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form action="proses_ulasan.php" method="POST">
        <div class="modal-header">
          <h5 class="modal-title">Beri Ulasan: <span id="modalJudulBuku"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id_buku" id="modalIdBuku">
          <label class="form-label d-block">Rating</label>
          <div class="rating-input mb-3">
            <input type="radio" name="rating" id="star5" value="5" required><label for="star5"><i class="bi bi-star-fill"></i></label>
            <input type="radio" name="rating" id="star4" value="4"><label for="star4"><i class="bi bi-star-fill"></i></label>
            <input type="radio" name="rating" id="star3" value="3"><label for="star3"><i class="bi bi-star-fill"></i></label>
            <input type="radio" name="rating" id="star2" value="2"><label for="star2"><i class="bi bi-star-fill"></i></label>
            <input type="radio" name="rating" id="star1" value="1"><label for="star1"><i class="bi bi-star-fill"></i></label>
          </div>
          <label class="form-label">Komentar</label>
          <textarea name="komentar" class="form-control" rows="3" placeholder="Tulis ulasanmu tentang buku ini..."></textarea>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-accent">Kirim Ulasan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
const ctx = document.getElementById('chartKategori');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: <?= $labels ?: '[]' ?>,
    datasets: [{
      label: 'Jumlah Judul Buku',
      data: <?= $values ?: '[]' ?>,
      backgroundColor: '#2653a3',
      borderRadius: 8
    }]
  },
  options: {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
  }
});

document.getElementById('modalUlasan').addEventListener('show.bs.modal', function (e) {
  const btn = e.relatedTarget;
  document.getElementById('modalIdBuku').value = btn.getAttribute('data-id');
  document.getElementById('modalJudulBuku').textContent = btn.getAttribute('data-judul');
});

document.getElementById('modalLihatUlasan').addEventListener('show.bs.modal', function (e) {
  const btn = e.relatedTarget;
  const idBuku = btn.getAttribute('data-id');
  document.getElementById('lihatJudulBuku').textContent = btn.getAttribute('data-judul');
  const body = document.getElementById('lihatUlasanBody');
  body.innerHTML = '<p class="text-muted text-center">Memuat ulasan...</p>';

  fetch('index.php?ajax_ulasan=1&id_buku=' + idBuku)
    .then(res => res.json())
    .then(data => {
      if (!data.length) {
        body.innerHTML = '<p class="text-muted text-center">Belum ada ulasan untuk buku ini.</p>';
        return;
      }
      let html = '';
      data.forEach(item => {
        let bintang = '';
        for (let i = 1; i <= 5; i++) {
          bintang += i <= item.rating
            ? '<i class="bi bi-star-fill" style="color:#f4a52a;"></i>'
            : '<i class="bi bi-star" style="color:#f4a52a;"></i>';
        }
        const komentar = item.komentar ? item.komentar.replace(/</g, '&lt;').replace(/>/g, '&gt;') : '<span class="text-muted fst-italic">Tanpa komentar</span>';
        html += `<div class="item-ulasan">
                   <div class="d-flex justify-content-between">
                     <strong>${item.nama.replace(/</g,'&lt;')}</strong>
                     <small class="text-muted">${item.tanggal}</small>
                   </div>
                   <div class="small mb-1">${bintang}</div>
                   <div class="small">${komentar}</div>
                 </div>`;
      });
      body.innerHTML = html;
    })
    .catch(() => {
      body.innerHTML = '<p class="text-danger text-center">Gagal memuat ulasan.</p>';
    });
});

// ===== Pop-up WhatsApp Mengambang =====
(function () {
  const waBtn = document.getElementById('waFloatBtn');
  const waPopup = document.getElementById('waPopup');
  const waClose = document.getElementById('waPopupClose');

  function toggleWaPopup() {
    waPopup.classList.toggle('show');
  }

  waBtn.addEventListener('click', toggleWaPopup);
  waClose.addEventListener('click', function (e) {
    e.stopPropagation();
    waPopup.classList.remove('show');
  });

  // Tutup pop-up jika klik di luar area pop-up & tombol
  document.addEventListener('click', function (e) {
    if (!waPopup.contains(e.target) && !waBtn.contains(e.target)) {
      waPopup.classList.remove('show');
    }
  });

  // Tampilkan otomatis sekali setelah beberapa detik (opsional, bisa dihapus)
  setTimeout(function () {
    waPopup.classList.add('show');
    setTimeout(function () {
      waPopup.classList.remove('show');
    }, 5000);
  }, 4000);
})();
</script>
</body>
</html>