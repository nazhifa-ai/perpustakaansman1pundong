<?php
require_once "config/functions.php";
$activeRole = $_GET['role'] ?? 'admin';
if (!in_array($activeRole, ['admin','petugas','siswa'])) $activeRole = 'admin';

$error = $_SESSION['login_error'] ?? '';
unset($_SESSION['login_error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Perpustakaan Sekolah Digital</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<style>
  /* === Video background login === */
  html, body {
    background: transparent !important;
  }
  .video-background {
    position: fixed !important;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    object-fit: cover;
    z-index: -2 !important;
  }
  .video-overlay {
    position: fixed !important;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 30, 0.55);
    z-index: -1 !important;
  }
  .login-wrapper {
    background: transparent !important;
  }
  .login-card {
    background: rgba(255, 255, 255, 0.85) !important;
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
  }
</style>
</head>
<body<?= $error ? ' data-login-notif="error"' : '' ?>>

<video class="video-background" autoplay muted loop playsinline>
  <source src="IMG/background.mp4" type="video/mp4">
</video>
<div class="video-overlay"></div>

<div class="login-wrapper">
  <div class="login-card" style="background: rgba(255,255,255,0.85); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); box-shadow: 0 8px 32px rgba(0,0,0,0.25);">
    <div class="text-center pt-4">
      <i class="bi bi-book-half" style="font-size:36px;color:var(--brand);"></i>
      <h5 class="fw-bold mt-2">Perpustakaan Sekolah Digital</h5>
      <a href="index.php" class="small">&larr; Kembali ke Beranda</a>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-danger mx-4 mt-3 py-2 small"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <ul class="nav nav-tabs nav-justified" id="loginTab" role="tablist">
      <li class="nav-item">
        <button class="nav-link <?= $activeRole=='admin'?'active':'' ?>" data-bs-toggle="tab" data-bs-target="#tab-admin" type="button">Admin</button>
      </li>
      <li class="nav-item">
        <button class="nav-link <?= $activeRole=='petugas'?'active':'' ?>" data-bs-toggle="tab" data-bs-target="#tab-petugas" type="button">Petugas</button>
      </li>
      <li class="nav-item">
        <button class="nav-link <?= $activeRole=='siswa'?'active':'' ?>" data-bs-toggle="tab" data-bs-target="#tab-siswa" type="button">Siswa</button>
      </li>
    </ul>

    <div class="tab-content">
      <!-- ADMIN -->
      <div class="tab-pane fade <?= $activeRole=='admin'?'show active':'' ?>" id="tab-admin">
        <form action="auth.php" method="POST">
          <input type="hidden" name="role" value="admin">
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required autofocus>
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <button type="submit" class="btn w-100 text-white" style="background:var(--brand);">Login sebagai Admin</button>
        </form>
      </div>

      <!-- PETUGAS -->
      <div class="tab-pane fade <?= $activeRole=='petugas'?'show active':'' ?>" id="tab-petugas">
        <form action="auth.php" method="POST">
          <input type="hidden" name="role" value="petugas">
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <button type="submit" class="btn w-100 text-white" style="background:var(--brand);">Login sebagai Petugas</button>
        </form>
      </div>

      <!-- SISWA -->
      <div class="tab-pane fade <?= $activeRole=='siswa'?'show active':'' ?>" id="tab-siswa">
        <form action="auth.php" method="POST">
          <input type="hidden" name="role" value="siswa">
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <button type="submit" class="btn w-100 text-white mb-2" style="background:var(--brand);">Login sebagai Siswa</button>
          <p class="text-center small mb-0">Belum punya akun? <a href="daftar.php">Daftar Anggota</a></p>
        </form>
      </div>
    </div>
    <div class="pb-4"></div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>