<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('siswa');
$pageTitle = "Riwayat Peminjaman";
$id_siswa = (int) $_SESSION['id'];

$data = mysqli_query($conn, "
  SELECT t.*, b.judul_buku, p.tanggal_kembali, p.denda, p.kondisi_buku
  FROM transaksi t
  JOIN buku b ON b.id_buku = t.id_buku
  LEFT JOIN pengembalian p ON p.id_transaksi = t.id_transaksi
  WHERE t.id_anggota = $id_siswa
  ORDER BY t.id_transaksi DESC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <div class="card-panel">
      <div class="table-responsive">
        <table class="table align-middle table-hover">
          <thead><tr><th>Buku</th><th>Tgl Pinjam</th><th>Jatuh Tempo</th><th>Tgl Kembali</th><th>Kondisi</th><th>Denda</th><th>Status</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($data) === 0): ?>
            <tr><td colspan="7" class="text-center text-muted">Belum ada riwayat peminjaman.</td></tr>
          <?php else: while ($r = mysqli_fetch_assoc($data)): ?>
            <tr>
              <td><?= htmlspecialchars($r['judul_buku']) ?></td>
              <td><?= formatTanggal($r['tanggal_pinjam']) ?></td>
              <td><?= formatTanggal($r['tanggal_jatuh_tempo']) ?></td>
              <td><?= $r['tanggal_kembali'] ? formatTanggal($r['tanggal_kembali']) : '-' ?></td>
              <td><?= $r['kondisi_buku'] ? badge($r['kondisi_buku']) : '-' ?></td>
              <td><?= $r['denda'] ? rupiah($r['denda']) : '-' ?></td>
              <td><?= badge($r['status']) ?></td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
</body>
</html>
