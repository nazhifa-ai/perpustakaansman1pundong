<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('siswa');
$pageTitle = "Dashboard Siswa";
$id_siswa = (int) $_SESSION['id'];

$loginNotif = $_SESSION['login_notif'] ?? '';
unset($_SESSION['login_notif']);

$sedangDipinjam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi WHERE id_anggota=$id_siswa AND status='Dipinjam'"))['c'];
$totalRiwayat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi WHERE id_anggota=$id_siswa"))['c'];
$telat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi WHERE id_anggota=$id_siswa AND status='Dipinjam' AND tanggal_jatuh_tempo < CURDATE()"))['c'];
$aktif = mysqli_query($conn, "
  SELECT t.*, b.judul_buku FROM transaksi t JOIN buku b ON b.id_buku=t.id_buku
  WHERE t.id_anggota=$id_siswa AND t.status='Dipinjam' ORDER BY t.tanggal_jatuh_tempo ASC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body<?= $loginNotif ? ' data-login-notif="'.htmlspecialchars($loginNotif).'"' : '' ?>>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <div class="alert alert-primary">Selamat datang, <b><?= htmlspecialchars($_SESSION['nama']) ?></b>! NIS: <?= htmlspecialchars($_SESSION['nisn']) ?></div>
    <div class="row g-3 mb-3">
      <div class="col-6 col-lg-4">
        <div class="stat-card"><div class="num"><?= $sedangDipinjam ?></div><small class="text-muted">Sedang Dipinjam</small></div>
      </div>
      <div class="col-6 col-lg-4">
        <div class="stat-card"><div class="num"><?= $totalRiwayat ?></div><small class="text-muted">Total Riwayat</small></div>
      </div>
      <div class="col-6 col-lg-4">
        <div class="stat-card"><div class="num text-danger"><?= $telat ?></div><small class="text-muted">Terlambat</small></div>
      </div>
    </div>
    <?php if ($telat > 0): ?>
      <div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i> Kamu memiliki buku yang <b>terlambat dikembalikan</b>. Segera kembalikan ke petugas perpustakaan.</div>
    <?php endif; ?>
    <div class="card-panel">
      <h6 class="fw-bold mb-3">Buku yang Sedang Kamu Pinjam</h6>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Judul Buku</th><th>Tgl Pinjam</th><th>Jatuh Tempo</th><th>Status</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($aktif) === 0): ?>
            <tr><td colspan="4" class="text-center text-muted">Tidak ada buku yang sedang dipinjam.</td></tr>
          <?php else: while ($a = mysqli_fetch_assoc($aktif)):
            $telatRow = strtotime($a['tanggal_jatuh_tempo']) < strtotime(date('Y-m-d')); ?>
            <tr>
              <td><?= htmlspecialchars($a['judul_buku']) ?></td>
              <td><?= formatTanggal($a['tanggal_pinjam']) ?></td>
              <td><?= formatTanggal($a['tanggal_jatuh_tempo']) ?></td>
              <td><?= $telatRow ? "<span class='badge bg-danger'>Terlambat</span>" : "<span class='badge bg-warning text-dark'>Dipinjam</span>" ?></td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
</body>
</html>