<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('siswa');
$pageTitle = "Ulasan Buku";
$id_siswa = (int) $_SESSION['id'];
$msg = "";

// SIMPAN / UPDATE ULASAN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $id_buku  = (int) $_POST['id_buku'];
    $rating   = max(1, min(5, (int) $_POST['rating']));
    $komentar = clean($conn, $_POST['komentar']);

    // Pastikan siswa memang pernah meminjam buku ini
    $cekPinjam = mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi WHERE id_anggota=$id_siswa AND id_buku=$id_buku");
    $pernahPinjam = mysqli_fetch_assoc($cekPinjam)['c'] > 0;

    if (!$pernahPinjam) {
        $msg = "Kamu hanya bisa memberi ulasan pada buku yang pernah kamu pinjam.";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO ulasan (id_buku, id_siswa, rating, komentar) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE rating=VALUES(rating), komentar=VALUES(komentar), tanggal=NOW()");
        mysqli_stmt_bind_param($stmt, "iiis", $id_buku, $id_siswa, $rating, $komentar);
        mysqli_stmt_execute($stmt);
        $msg = "Ulasan berhasil disimpan. Terima kasih!";
    }
}

// HAPUS ULASAN
if (isset($_GET['hapus'])) {
    $id_buku = (int) $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM ulasan WHERE id_buku=$id_buku AND id_siswa=$id_siswa");
    $msg = "Ulasan berhasil dihapus.";
}

// Daftar buku yang pernah dipinjam siswa ini + ulasan yang sudah ada (jika ada)
$listBuku = mysqli_query($conn, "
  SELECT DISTINCT b.id_buku, b.judul_buku, b.penulis, b.kategori, b.sampul,
         u.rating AS rating_saya, u.komentar AS komentar_saya
  FROM transaksi t
  JOIN buku b ON b.id_buku = t.id_buku
  LEFT JOIN ulasan u ON u.id_buku = b.id_buku AND u.id_siswa = $id_siswa
  WHERE t.id_anggota = $id_siswa
  ORDER BY b.judul_buku ASC
");

$uploadDir = "../uploads/buku/";
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
<style>
.cover-ulasan { width:70px; height:95px; object-fit:cover; border-radius:6px; background:#f1f3f5; }
.cover-ulasan-placeholder { width:70px; height:95px; border-radius:6px; background:#eef1f6; display:flex; align-items:center; justify-content:center; color:#a9b3c1; font-size:1.6rem; }
.star-input { font-size: 1.6rem; cursor: pointer; }
.star-input .bi-star-fill { color: #f4a52a; }
.star-input .bi-star { color: #ced4da; }
</style>
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-info"><?= $msg ?></div><?php endif; ?>

    <div class="card-panel">
      <h6 class="fw-bold mb-3">Buku yang Pernah Kamu Pinjam</h6>
      <div class="row g-3">
        <?php if (mysqli_num_rows($listBuku) === 0): ?>
          <p class="text-muted text-center">Kamu belum pernah meminjam buku apa pun.</p>
        <?php else: while ($b = mysqli_fetch_assoc($listBuku)): ?>
          <div class="col-md-6">
            <div class="border rounded-3 p-3 d-flex gap-3">
              <?php if (!empty($b['sampul']) && file_exists($uploadDir . $b['sampul'])): ?>
                <img src="<?= $uploadDir . htmlspecialchars($b['sampul']) ?>" class="cover-ulasan flex-shrink-0" alt="Sampul">
              <?php else: ?>
                <div class="cover-ulasan-placeholder flex-shrink-0"><i class="bi bi-book"></i></div>
              <?php endif; ?>
              <div class="flex-grow-1">
                <h6 class="fw-bold mb-1"><?= htmlspecialchars($b['judul_buku']) ?></h6>
                <p class="text-muted small mb-2"><?= htmlspecialchars($b['penulis']) ?> &middot; <?= htmlspecialchars($b['kategori']) ?></p>

                <form method="POST" class="ulasan-form">
                  <input type="hidden" name="id_buku" value="<?= $b['id_buku'] ?>">
                  <input type="hidden" name="rating" class="rating-value" value="<?= $b['rating_saya'] ?: 5 ?>">
                  <div class="star-input mb-2" data-target="rating-<?= $b['id_buku'] ?>">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                      <i class="bi <?= $i <= ($b['rating_saya'] ?: 0) ? 'bi-star-fill' : 'bi-star' ?>" data-value="<?= $i ?>"></i>
                    <?php endfor; ?>
                  </div>
                  <textarea name="komentar" class="form-control form-control-sm mb-2" rows="2" placeholder="Tulis ulasan singkat (opsional)"><?= htmlspecialchars($b['komentar_saya'] ?? '') ?></textarea>
                  <div class="d-flex gap-2">
                    <button type="submit" name="simpan" class="btn btn-sm btn-primary">
                      <?= $b['rating_saya'] ? 'Perbarui Ulasan' : 'Kirim Ulasan' ?>
                    </button>
                    <?php if ($b['rating_saya']): ?>
                      <a href="?hapus=<?= $b['id_buku'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirmDelete('Hapus ulasanmu untuk buku ini?')">Hapus</a>
                    <?php endif; ?>
                  </div>
                </form>
              </div>
            </div>
          </div>
        <?php endwhile; endif; ?>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
// Interaksi klik bintang untuk memilih rating
document.querySelectorAll('.star-input').forEach(function (starWrap) {
  const stars = starWrap.querySelectorAll('i');
  const hiddenInput = starWrap.closest('form').querySelector('.rating-value');

  stars.forEach(function (star) {
    star.addEventListener('click', function () {
      const val = parseInt(this.dataset.value);
      hiddenInput.value = val;
      stars.forEach(function (s) {
        s.classList.toggle('bi-star-fill', parseInt(s.dataset.value) <= val);
        s.classList.toggle('bi-star', parseInt(s.dataset.value) > val);
      });
    });
  });
});
</script>
</body>
</html>