<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('siswa');
$pageTitle = "Profil Siswa";
$id_siswa = (int) $_SESSION['id'];
$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $nama    = clean($conn, $_POST['nama']);
    $kelas   = clean($conn, $_POST['kelas']);
    $jurusan = clean($conn, $_POST['jurusan']);
    $no_telp = clean($conn, $_POST['no_telp']);
    $alamat  = clean($conn, $_POST['alamat']);
    $password = $_POST['password'];

    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = mysqli_prepare($conn, "UPDATE siswa SET nama=?, kelas=?, jurusan=?, no_telp=?, alamat=?, password=? WHERE id_siswa=?");
        mysqli_stmt_bind_param($stmt, "ssssssi", $nama, $kelas, $jurusan, $no_telp, $alamat, $hash, $id_siswa);
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE siswa SET nama=?, kelas=?, jurusan=?, no_telp=?, alamat=? WHERE id_siswa=?");
        mysqli_stmt_bind_param($stmt, "sssssi", $nama, $kelas, $jurusan, $no_telp, $alamat, $id_siswa);
    }
    mysqli_stmt_execute($stmt);
    $_SESSION['nama'] = $nama;
    $msg = "Profil berhasil diperbarui.";
}

$siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM siswa WHERE id_siswa=$id_siswa"));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <div class="card-panel" style="max-width:600px;">
      <form method="POST">
        <div class="row g-2">
          <div class="col-6"><label class="form-label">NISN</label><input type="text" class="form-control" value="<?= htmlspecialchars($siswa['nisn']) ?>" disabled></div>
          <div class="col-6"><label class="form-label">Username</label><input type="text" class="form-control" value="<?= htmlspecialchars($siswa['username']) ?>" disabled></div>
          <div class="col-12"><label class="form-label">Nama Lengkap</label><input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($siswa['nama']) ?>" required></div>
          <div class="col-6"><label class="form-label">Kelas</label><input type="text" name="kelas" class="form-control" value="<?= htmlspecialchars($siswa['kelas']) ?>"></div>
          <div class="col-6"><label class="form-label">Jurusan</label><input type="text" name="jurusan" class="form-control" value="<?= htmlspecialchars($siswa['jurusan']) ?>"></div>
          <div class="col-12"><label class="form-label">No. Telepon</label><input type="text" name="no_telp" class="form-control" value="<?= htmlspecialchars($siswa['no_telp']) ?>"></div>
          <div class="col-12"><label class="form-label">Alamat</label><textarea name="alamat" class="form-control" rows="2"><?= htmlspecialchars($siswa['alamat']) ?></textarea></div>
          <div class="col-12"><label class="form-label">Password Baru <small class="text-muted">(kosongkan jika tidak diubah)</small></label><input type="password" name="password" class="form-control"></div>
        </div>
        <button type="submit" name="simpan" class="btn btn-primary w-100 mt-3">Simpan Perubahan</button>
      </form>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
</body>
</html>
