<?php $cur = basename($_SERVER['PHP_SELF']); ?>
<div class="sidebar" id="sidebarEl">
  <div class="brand"><i class="bi bi-book-half me-2"></i>Perpus Siswa</div>
  <nav class="nav flex-column py-2">
    <a class="nav-link <?= $cur=='dashboard.php'?'active':'' ?>" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a class="nav-link <?= $cur=='peminjaman.php'?'active':'' ?>" href="peminjaman.php"><i class="bi bi-journal-plus"></i> Peminjaman</a>
    <a class="nav-link <?= $cur=='riwayat.php'?'active':'' ?>" href="riwayat.php"><i class="bi bi-clock-history"></i> Riwayat Peminjaman</a>
    <a class="nav-link <?= $cur=='ulasan.php'?'active':'' ?>" href="ulasan.php"><i class="bi bi-star"></i> Ulasan Buku</a>
    <a class="nav-link <?= $cur=='profil.php'?'active':'' ?>" href="profil.php"><i class="bi bi-person-circle"></i> Profil Siswa</a>
    <hr class="mx-3" style="border-color: rgba(255,255,255,.15);">
    <a class="nav-link" href="logout.php" onclick="return confirmDelete('Yakin ingin logout?')"><i class="bi bi-box-arrow-right"></i> Logout</a>
  </nav>
</div>
