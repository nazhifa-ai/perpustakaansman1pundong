<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('siswa');
$pageTitle = "Peminjaman Buku";
$id_siswa = (int) $_SESSION['id'];
$msg = ""; $msgType = "info";

$uploadDir = "../uploads/buku/";

$MAKS_PINJAM = 3;
$sedangDipinjam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi WHERE id_anggota=$id_siswa AND status='Dipinjam'"))['c'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pinjam'])) {
    $id_buku = (int) $_POST['id_buku'];
    $lama = 7; // default masa pinjam 7 hari
    $tgl_pinjam = date('Y-m-d');
    $jatuh_tempo = date('Y-m-d', strtotime("+$lama days"));

    if ($sedangDipinjam >= $MAKS_PINJAM) {
        $msg = "Kamu sudah mencapai batas maksimal $MAKS_PINJAM buku dipinjam sekaligus.";
        $msgType = "danger";
    } else {
        $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT buku_tersedia FROM buku WHERE id_buku=$id_buku"));
        if ($cek && $cek['buku_tersedia'] > 0) {
            $stmt = mysqli_prepare($conn, "INSERT INTO transaksi (id_anggota, id_buku, tanggal_pinjam, tanggal_jatuh_tempo, status) VALUES (?,?,?,?,'Dipinjam')");
            mysqli_stmt_bind_param($stmt, "iiss", $id_siswa, $id_buku, $tgl_pinjam, $jatuh_tempo);
            mysqli_stmt_execute($stmt);
            mysqli_query($conn, "UPDATE buku SET buku_tersedia = buku_tersedia - 1 WHERE id_buku=$id_buku");
            $msg = "Peminjaman berhasil! Batas pengembalian: " . formatTanggal($jatuh_tempo);
            $msgType = "success";
            $sedangDipinjam++;
        } else {
            $msg = "Maaf, stok buku ini sedang habis.";
            $msgType = "danger";
        }
    }
}

$keyword = clean($conn, $_GET['q'] ?? '');
$listBuku = mysqli_query($conn, "SELECT * FROM buku WHERE (judul_buku LIKE '%$keyword%' OR kategori LIKE '%$keyword%' OR penulis LIKE '%$keyword%') AND buku_tersedia > 0 ORDER BY judul_buku ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
<style>
.cover-book {
  width: 100%;
  height: 190px;
  object-fit: cover;
  border-radius: 8px;
  margin-bottom: 10px;
  background: #f1f3f5;
}
.cover-placeholder {
  width: 100%;
  height: 190px;
  border-radius: 8px;
  margin-bottom: 10px;
  background: #f1f3f5;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #adb5bd;
  font-size: 2.5rem;
}
</style>
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= $msg ?></div><?php endif; ?>
    <div class="alert alert-light border small">Kamu sedang meminjam <b><?= $sedangDipinjam ?></b> dari maksimal <b><?= $MAKS_PINJAM ?></b> buku.</div>

    <div class="card-panel">
      <form class="d-flex mb-3" method="GET" style="max-width:320px;">
        <input type="text" name="q" class="form-control form-control-sm" placeholder="Cari judul/kategori/penulis" value="<?= htmlspecialchars($keyword) ?>">
        <button class="btn btn-sm btn-primary ms-1"><i class="bi bi-search"></i></button>
      </form>
      <div class="row g-3">
        <?php if (mysqli_num_rows($listBuku) === 0): ?>
          <p class="text-muted text-center">Tidak ada buku tersedia untuk dipinjam saat ini.</p>
        <?php else: while ($b = mysqli_fetch_assoc($listBuku)): ?>
        <div class="col-md-6 col-lg-4">
          <div class="border rounded-3 p-3 h-100 d-flex flex-column">
            <?php if (!empty($b['sampul']) && file_exists($uploadDir . $b['sampul'])): ?>
              <img src="<?= $uploadDir . htmlspecialchars($b['sampul']) ?>" class="cover-book" alt="Sampul <?= htmlspecialchars($b['judul_buku']) ?>">
            <?php else: ?>
              <div class="cover-placeholder"><i class="bi bi-book"></i></div>
            <?php endif; ?>
            <span class="badge bg-secondary align-self-start mb-2"><?= htmlspecialchars($b['kategori']) ?></span>
            <h6 class="fw-bold"><?= htmlspecialchars($b['judul_buku']) ?></h6>
            <p class="text-muted small mb-1">Penulis: <?= htmlspecialchars($b['penulis']) ?></p>
            <?php $r = getRatingBuku($conn, $b['id_buku']); ?>
            <p class="small mb-1">
              <?= renderBintang($r['rata'], '0.9rem') ?>
              <span class="text-muted">(<?= $r['jml'] ?> ulasan)</span>
            </p>
            <p class="text-muted small mb-2">Tersedia: <?= $b['buku_tersedia'] ?> eksemplar</p>
            <form method="POST" class="mt-auto">
              <input type="hidden" name="id_buku" value="<?= $b['id_buku'] ?>">
              <button type="submit" name="pinjam" class="btn btn-primary btn-sm w-100" <?= $sedangDipinjam >= $MAKS_PINJAM ? 'disabled' : '' ?>>
                <i class="bi bi-journal-plus"></i> Pinjam
              </button>
            </form>
          </div>
        </div>
        <?php endwhile; endif; ?>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
</body>
</html>