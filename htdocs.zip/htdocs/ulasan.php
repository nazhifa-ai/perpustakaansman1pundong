<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('siswa');
$pageTitle = "Ulasan Buku";
$id_siswa = (int) $_SESSION['id'];
$msg = ""; $msgType = "info";

$uploadDir = "../uploads/buku/";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kirim_ulasan'])) {
    $id_buku  = (int) $_POST['id_buku'];
    $rating   = (int) $_POST['rating'];
    $komentar = clean($conn, $_POST['komentar'] ?? '');

    if ($id_buku <= 0 || $rating < 1 || $rating > 5) {
        $msg = "Rating wajib dipilih (1-5 bintang).";
        $msgType = "danger";
    } else {
        $cek = mysqli_prepare($conn, "SELECT id_ulasan FROM ulasan WHERE id_buku=? AND id_siswa=? LIMIT 1");
        mysqli_stmt_bind_param($cek, "ii", $id_buku, $id_siswa);
        mysqli_stmt_execute($cek);
        $row = mysqli_stmt_get_result($cek)->fetch_assoc();

        if ($row) {
            $stmt = mysqli_prepare($conn, "UPDATE ulasan SET rating=?, komentar=?, tanggal=NOW() WHERE id_ulasan=?");
            mysqli_stmt_bind_param($stmt, "isi", $rating, $komentar, $row['id_ulasan']);
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO ulasan (id_buku, id_siswa, rating, komentar) VALUES (?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "iiis", $id_buku, $id_siswa, $rating, $komentar);
        }
        mysqli_stmt_execute($stmt);
        $msg = "Terima kasih! Ulasanmu berhasil disimpan.";
        $msgType = "success";
    }
}

$keyword = clean($conn, $_GET['q'] ?? '');
$listBuku = mysqli_query($conn, "
  SELECT b.*, COALESCE(AVG(u.rating),0) AS rata, COUNT(u.id_ulasan) AS jml,
         (SELECT rating FROM ulasan WHERE id_buku=b.id_buku AND id_siswa=$id_siswa LIMIT 1) AS rating_saya,
         (SELECT komentar FROM ulasan WHERE id_buku=b.id_buku AND id_siswa=$id_siswa LIMIT 1) AS komentar_saya
  FROM buku b
  LEFT JOIN ulasan u ON u.id_buku = b.id_buku
  WHERE (b.judul_buku LIKE '%$keyword%' OR b.kategori LIKE '%$keyword%' OR b.penulis LIKE '%$keyword%')
  GROUP BY b.id_buku
  ORDER BY b.judul_buku ASC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
<style>
.cover-book {
  width: 100%;
  height: 190px;
  object-fit: cover;
  border-radius: 8px;
  margin-bottom: 10px;
  background: #f1f3f5;
}
.cover-placeholder {
  width: 100%;
  height: 190px;
  border-radius: 8px;
  margin-bottom: 10px;
  background: #f1f3f5;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #adb5bd;
  font-size: 2.5rem;
}
.rating-input {
  display: flex;
  flex-direction: row-reverse;
  justify-content: flex-end;
  font-size: 2rem;
}
.rating-input input { display: none; }
.rating-input label {
  color: #dcdcdc;
  cursor: pointer;
  padding: 0 2px;
}
.rating-input input:checked ~ label,
.rating-input label:hover,
.rating-input label:hover ~ label {
  color: #f4a52a;
}
</style>
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= $msg ?></div><?php endif; ?>

    <div class="card-panel">
      <form class="d-flex mb-3" method="GET" style="max-width:320px;">
        <input type="text" name="q" class="form-control form-control-sm" placeholder="Cari judul/kategori/penulis" value="<?= htmlspecialchars($keyword) ?>">
        <button class="btn btn-sm btn-primary ms-1"><i class="bi bi-search"></i></button>
      </form>
      <div class="row g-3">
        <?php if (mysqli_num_rows($listBuku) === 0): ?>
          <p class="text-muted text-center">Tidak ada buku ditemukan.</p>
        <?php else: while ($b = mysqli_fetch_assoc($listBuku)): ?>
        <div class="col-md-6 col-lg-4">
          <div class="border rounded-3 p-3 h-100 d-flex flex-column">
            <?php if (!empty($b['sampul']) && file_exists($uploadDir . $b['sampul'])): ?>
              <img src="<?= $uploadDir . htmlspecialchars($b['sampul']) ?>" class="cover-book" alt="Sampul <?= htmlspecialchars($b['judul_buku']) ?>">
            <?php else: ?>
              <div class="cover-placeholder"><i class="bi bi-book"></i></div>
            <?php endif; ?>
            <span class="badge bg-secondary align-self-start mb-2"><?= htmlspecialchars($b['kategori']) ?></span>
            <h6 class="fw-bold"><?= htmlspecialchars($b['judul_buku']) ?></h6>
            <p class="text-muted small mb-1">Penulis: <?= htmlspecialchars($b['penulis']) ?></p>
            <p class="small mb-2">
              <?= renderBintang($b['rata'], '0.9rem') ?>
              <span class="text-muted">(<?= $b['jml'] ?> ulasan)</span>
            </p>
            <?php if ($b['rating_saya']): ?>
              <p class="small text-success mb-2"><i class="bi bi-check-circle"></i> Kamu sudah mengulas buku ini</p>
            <?php endif; ?>
            <button type="button" class="btn btn-outline-primary btn-sm w-100 mt-auto btn-ulasan"
                    data-bs-toggle="modal" data-bs-target="#modalUlasan"
                    data-id="<?= $b['id_buku'] ?>"
                    data-judul="<?= htmlspecialchars($b['judul_buku'], ENT_QUOTES) ?>"
                    data-rating="<?= (int)($b['rating_saya'] ?? 0) ?>"
                    data-komentar="<?= htmlspecialchars($b['komentar_saya'] ?? '', ENT_QUOTES) ?>">
              <i class="bi bi-star"></i> <?= $b['rating_saya'] ? 'Edit Ulasan' : 'Beri Ulasan' ?>
            </button>
          </div>
        </div>
        <?php endwhile; endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- MODAL ULASAN -->
<div class="modal fade" id="modalUlasan" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="POST">
        <div class="modal-header">
          <h5 class="modal-title">Beri Ulasan: <span id="modalJudulBuku"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id_buku" id="modalIdBuku">
          <label class="form-label d-block">Rating</label>
          <div class="rating-input mb-3">
            <input type="radio" name="rating" id="star5" value="5" required><label for="star5"><i class="bi bi-star-fill"></i></label>
            <input type="radio" name="rating" id="star4" value="4"><label for="star4"><i class="bi bi-star-fill"></i></label>
            <input type="radio" name="rating" id="star3" value="3"><label for="star3"><i class="bi bi-star-fill"></i></label>
            <input type="radio" name="rating" id="star2" value="2"><label for="star2"><i class="bi bi-star-fill"></i></label>
            <input type="radio" name="rating" id="star1" value="1"><label for="star1"><i class="bi bi-star-fill"></i></label>
          </div>
          <label class="form-label">Komentar</label>
          <textarea name="komentar" id="modalKomentar" class="form-control" rows="3" placeholder="Tulis ulasanmu tentang buku ini..."></textarea>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" name="kirim_ulasan" class="btn btn-primary">Kirim Ulasan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
document.getElementById('modalUlasan').addEventListener('show.bs.modal', function (e) {
  const btn = e.relatedTarget;
  document.getElementById('modalIdBuku').value = btn.getAttribute('data-id');
  document.getElementById('modalJudulBuku').textContent = btn.getAttribute('data-judul');
  document.getElementById('modalKomentar').value = btn.getAttribute('data-komentar') || '';

  // reset semua pilihan bintang dulu
  document.querySelectorAll('.rating-input input').forEach(r => r.checked = false);
  const ratingSaya = btn.getAttribute('data-rating');
  if (ratingSaya && ratingSaya !== '0') {
    const target = document.getElementById('star' + ratingSaya);
    if (target) target.checked = true;
  }
});
</script>
</body>
</html>