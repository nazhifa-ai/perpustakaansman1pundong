<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('petugas');
$pageTitle = "Dashboard Petugas";

$loginNotif = $_SESSION['login_notif'] ?? '';
unset($_SESSION['login_notif']);

$totalBuku = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM buku"))['c'];
$totalDipinjam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi WHERE status='Dipinjam'"))['c'];
$totalTelat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi WHERE status='Dipinjam' AND tanggal_jatuh_tempo < CURDATE()"))['c'];
$bukuRusak = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM buku WHERE kondisi != 'Baik'"))['c'];
$antrian = mysqli_query($conn, "
  SELECT t.*, b.judul_buku, s.nama, s.nisn FROM transaksi t
  JOIN buku b ON b.id_buku=t.id_buku JOIN siswa s ON s.id_siswa=t.id_anggota
  WHERE t.status='Dipinjam' ORDER BY t.tanggal_jatuh_tempo ASC LIMIT 8
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body<?= $loginNotif ? ' data-login-notif="'.htmlspecialchars($loginNotif).'"' : '' ?>>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <div class="row g-3 mb-3">
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="num"><?= $totalBuku ?></div><small class="text-muted">Judul Buku</small></div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="num"><?= $totalDipinjam ?></div><small class="text-muted">Sedang Dipinjam</small></div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="num text-danger"><?= $totalTelat ?></div><small class="text-muted">Terlambat</small></div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card"><div class="num text-warning"><?= $bukuRusak ?></div><small class="text-muted">Kondisi Bermasalah</small></div>
      </div>
    </div>
    <div class="card-panel">
      <h6 class="fw-bold mb-3">Peminjaman Aktif (Terdekat Jatuh Tempo)</h6>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Siswa</th><th>NISN</th><th>Buku</th><th>Jatuh Tempo</th><th>Status</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($antrian) === 0): ?>
            <tr><td colspan="5" class="text-center text-muted">Tidak ada peminjaman aktif.</td></tr>
          <?php else: while ($a = mysqli_fetch_assoc($antrian)):
            $telat = strtotime($a['tanggal_jatuh_tempo']) < strtotime(date('Y-m-d')); ?>
            <tr>
              <td><?= htmlspecialchars($a['nama']) ?></td>
              <td><?= htmlspecialchars($a['nisn']) ?></td>
              <td><?= htmlspecialchars($a['judul_buku']) ?></td>
              <td><?= formatTanggal($a['tanggal_jatuh_tempo']) ?></td>
              <td><?= $telat ? "<span class='badge bg-danger'>Terlambat</span>" : "<span class='badge bg-warning text-dark'>Dipinjam</span>" ?></td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
</body>
</html>