<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('petugas');
$pageTitle = "Cek Kondisi Buku";
$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan_kondisi'])) {
    $id_buku = (int) $_POST['id_buku'];
    $kondisi = clean($conn, $_POST['kondisi']);
    $stmt = mysqli_prepare($conn, "UPDATE buku SET kondisi=? WHERE id_buku=?");
    mysqli_stmt_bind_param($stmt, "si", $kondisi, $id_buku);
    mysqli_stmt_execute($stmt);
    $msg = "Kondisi buku berhasil diperbarui.";
}

$keyword = clean($conn, $_GET['q'] ?? '');
$data = mysqli_query($conn, "SELECT * FROM buku WHERE judul_buku LIKE '%$keyword%' OR kode_buku LIKE '%$keyword%' ORDER BY judul_buku ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <div class="card-panel">
      <p class="text-muted small">Periksa dan perbarui kondisi fisik buku secara berkala (Baik / Rusak / Hilang).</p>
      <form class="d-flex mb-3" method="GET" style="max-width:320px;">
        <input type="text" name="q" class="form-control form-control-sm" placeholder="Cari judul/kode buku" value="<?= htmlspecialchars($keyword) ?>">
        <button class="btn btn-sm btn-primary ms-1"><i class="bi bi-search"></i></button>
      </form>
      <div class="table-responsive">
        <table class="table align-middle table-hover">
          <thead><tr><th>Kode</th><th>Judul Buku</th><th>Rak</th><th>Kondisi Saat Ini</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($data) === 0): ?>
            <tr><td colspan="5" class="text-center text-muted">Tidak ada data buku.</td></tr>
          <?php else: while ($b = mysqli_fetch_assoc($data)): ?>
            <tr>
              <td><?= htmlspecialchars($b['kode_buku']) ?></td>
              <td><?= htmlspecialchars($b['judul_buku']) ?></td>
              <td><?= htmlspecialchars($b['lokasi_rak']) ?></td>
              <td><?= badge($b['kondisi']) ?></td>
              <td>
                <button class="btn btn-sm btn-outline-primary" onclick='ubahKondisi(<?= json_encode($b) ?>)'><i class="bi bi-clipboard2-check"></i> Update</button>
              </td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="modalKondisi" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST">
      <div class="modal-header"><h5 class="modal-title">Update Kondisi Buku</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <input type="hidden" name="id_buku" id="id_buku">
        <p class="mb-2">Buku: <b id="judulBuku"></b></p>
        <label class="form-label">Kondisi</label>
        <select name="kondisi" id="kondisi" class="form-select" required>
          <option value="Baik">Baik</option>
          <option value="Rusak">Rusak</option>
          <option value="Hilang">Hilang</option>
        </select>
      </div>
      <div class="modal-footer"><button type="submit" name="simpan_kondisi" class="btn btn-primary w-100">Simpan</button></div>
    </form>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
function ubahKondisi(b) {
  document.getElementById('id_buku').value = b.id_buku;
  document.getElementById('judulBuku').innerText = b.judul_buku;
  document.getElementById('kondisi').value = b.kondisi;
  new bootstrap.Modal(document.getElementById('modalKondisi')).show();
}
</script>
</body>
</html>
