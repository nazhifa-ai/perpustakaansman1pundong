<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('petugas');
$pageTitle = "Transaksi Peminjaman & Pengembalian";
$msg = ""; $msgType = "info";
$siswaDitemukan = null;

// ================= CARI SISWA BERDASARKAN NIS =================
if (isset($_POST['cari_nis'])) {
    $nis = clean($conn, $_POST['nis_cari']);
    $stmt = mysqli_prepare($conn, "SELECT * FROM siswa WHERE nisn=?");
    mysqli_stmt_bind_param($stmt, "s", $nis);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $siswaDitemukan = mysqli_fetch_assoc($res);
    if (!$siswaDitemukan) {
        $msg = "NIS tidak ditemukan. Pastikan siswa sudah terdaftar sebagai anggota.";
        $msgType = "danger";
    }
}

// ================= PROSES PEMINJAMAN =================
if (isset($_POST['proses_pinjam'])) {
    $id_anggota = (int) $_POST['id_anggota'];
    $id_buku    = (int) $_POST['id_buku'];
    $lama       = (int) $_POST['lama_hari'];
    $tgl_pinjam = date('Y-m-d');
    $jatuh_tempo = date('Y-m-d', strtotime("+$lama days"));

    $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT buku_tersedia FROM buku WHERE id_buku=$id_buku"));
    if ($cek && $cek['buku_tersedia'] > 0) {
        $stmt = mysqli_prepare($conn, "INSERT INTO transaksi (id_anggota, id_buku, tanggal_pinjam, tanggal_jatuh_tempo, status) VALUES (?,?,?,?,'Dipinjam')");
        mysqli_stmt_bind_param($stmt, "iiss", $id_anggota, $id_buku, $tgl_pinjam, $jatuh_tempo);
        mysqli_stmt_execute($stmt);
        mysqli_query($conn, "UPDATE buku SET buku_tersedia = buku_tersedia - 1 WHERE id_buku=$id_buku");
        $msg = "Peminjaman berhasil dicatat. Jatuh tempo: " . formatTanggal($jatuh_tempo);
        $msgType = "success";
    } else {
        $msg = "Stok buku tidak tersedia.";
        $msgType = "danger";
    }
}

// ================= PROSES PENGEMBALIAN (dengan konfirmasi NIS) =================
if (isset($_POST['proses_kembali'])) {
    $id_transaksi = (int) $_POST['id_transaksi'];
    $nis_konfirmasi = clean($conn, $_POST['nis_konfirmasi']);
    $kondisi = clean($conn, $_POST['kondisi_buku']);

    $trx = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT t.*, s.nisn, s.nama, b.id_buku FROM transaksi t
        JOIN siswa s ON s.id_siswa = t.id_anggota
        JOIN buku b ON b.id_buku = t.id_buku
        WHERE t.id_transaksi = $id_transaksi
    "));

    if (!$trx) {
        $msg = "Transaksi tidak ditemukan.";
        $msgType = "danger";
    } elseif ($trx['nisn'] !== $nis_konfirmasi) {
        $msg = "Konfirmasi NIS tidak sesuai dengan data peminjam. Pengembalian dibatalkan.";
        $msgType = "danger";
    } else {
        $tgl_kembali = date('Y-m-d');
        $denda = hitungDenda($trx['tanggal_jatuh_tempo'], $tgl_kembali);
        if ($kondisi === 'Rusak') $denda += 5000;
        if ($kondisi === 'Hilang') $denda += 50000;

        $stmt = mysqli_prepare($conn, "INSERT INTO pengembalian (id_transaksi, tanggal_kembali, denda, kondisi_buku) VALUES (?,?,?,?)");
        mysqli_stmt_bind_param($stmt, "isds", $id_transaksi, $tgl_kembali, $denda, $kondisi);
        mysqli_stmt_execute($stmt);

        mysqli_query($conn, "UPDATE transaksi SET status='Dikembalikan' WHERE id_transaksi=$id_transaksi");
        if ($kondisi !== 'Hilang') {
            mysqli_query($conn, "UPDATE buku SET buku_tersedia = buku_tersedia + 1 WHERE id_buku=" . (int)$trx['id_buku']);
        }
        if ($kondisi !== 'Baik') {
            mysqli_query($conn, "UPDATE buku SET kondisi='$kondisi' WHERE id_buku=" . (int)$trx['id_buku']);
        }
        $msg = "Pengembalian berhasil diproses untuk {$trx['nama']}. Denda: " . rupiah($denda);
        $msgType = "success";
    }
}

$listBuku = mysqli_query($conn, "SELECT id_buku, judul_buku, buku_tersedia FROM buku WHERE buku_tersedia > 0 ORDER BY judul_buku");

$aktif = mysqli_query($conn, "
  SELECT t.*, b.judul_buku, s.nama, s.nisn FROM transaksi t
  JOIN buku b ON b.id_buku=t.id_buku JOIN siswa s ON s.id_siswa=t.id_anggota
  WHERE t.status='Dipinjam' ORDER BY t.tanggal_jatuh_tempo ASC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= $msg ?></div><?php endif; ?>

    <ul class="nav nav-tabs mb-3">
      <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tabPinjam">Peminjaman (Tunjukkan NIS)</button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabKembali">Pengembalian</button></li>
    </ul>

    <div class="tab-content">
      <!-- ===== TAB PEMINJAMAN ===== -->
      <div class="tab-pane fade show active" id="tabPinjam">
        <div class="card-panel mb-3">
          <h6 class="fw-bold mb-3"><i class="bi bi-person-vcard"></i> Langkah 1: Cari Siswa dengan NIS</h6>
          <form class="row g-2" method="POST">
            <div class="col-auto"><input type="text" name="nis_cari" class="form-control" placeholder="Masukkan NIS siswa" required value="<?= htmlspecialchars($_POST['nis_cari'] ?? '') ?>"></div>
            <div class="col-auto"><button type="submit" name="cari_nis" class="btn btn-primary">Cari</button></div>
          </form>
        </div>

        <?php if ($siswaDitemukan): ?>
        <div class="card-panel">
          <h6 class="fw-bold mb-3"><i class="bi bi-journal-plus"></i> Langkah 2: Pilih Buku untuk <?= htmlspecialchars($siswaDitemukan['nama']) ?></h6>
          <div class="alert alert-light border">
            <b>Nama:</b> <?= htmlspecialchars($siswaDitemukan['nama']) ?> &middot;
            <b>NIS:</b> <?= htmlspecialchars($siswaDitemukan['nisn']) ?> &middot;
            <b>Kelas:</b> <?= htmlspecialchars($siswaDitemukan['kelas']) ?>
          </div>
          <form class="row g-2" method="POST">
            <input type="hidden" name="id_anggota" value="<?= $siswaDitemukan['id_siswa'] ?>">
            <div class="col-md-5">
              <select name="id_buku" class="form-select" required>
                <option value="">-- Pilih Buku --</option>
                <?php mysqli_data_seek($listBuku, 0); while ($b = mysqli_fetch_assoc($listBuku)): ?>
                  <option value="<?= $b['id_buku'] ?>"><?= htmlspecialchars($b['judul_buku']) ?> (tersisa <?= $b['buku_tersedia'] ?>)</option>
                <?php endwhile; ?>
              </select>
            </div>
            <div class="col-md-3">
              <input type="number" name="lama_hari" class="form-control" value="7" min="1" placeholder="Lama pinjam (hari)" required>
            </div>
            <div class="col-md-3">
              <button type="submit" name="proses_pinjam" class="btn btn-success w-100">Proses Peminjaman</button>
            </div>
          </form>
        </div>
        <?php endif; ?>
      </div>

      <!-- ===== TAB PENGEMBALIAN ===== -->
      <div class="tab-pane fade" id="tabKembali">
        <div class="card-panel">
          <h6 class="fw-bold mb-3">Daftar Buku Dipinjam</h6>
          <div class="table-responsive">
            <table class="table align-middle table-hover">
              <thead><tr><th>Siswa</th><th>NIS</th><th>Buku</th><th>Jatuh Tempo</th><th>Status</th><th>Aksi</th></tr></thead>
              <tbody>
              <?php if (mysqli_num_rows($aktif) === 0): ?>
                <tr><td colspan="6" class="text-center text-muted">Tidak ada peminjaman aktif.</td></tr>
              <?php else: while ($a = mysqli_fetch_assoc($aktif)):
                $telat = strtotime($a['tanggal_jatuh_tempo']) < strtotime(date('Y-m-d')); ?>
                <tr>
                  <td><?= htmlspecialchars($a['nama']) ?></td>
                  <td><?= htmlspecialchars($a['nisn']) ?></td>
                  <td><?= htmlspecialchars($a['judul_buku']) ?></td>
                  <td><?= formatTanggal($a['tanggal_jatuh_tempo']) ?></td>
                  <td><?= $telat ? "<span class='badge bg-danger'>Terlambat</span>" : "<span class='badge bg-warning text-dark'>Dipinjam</span>" ?></td>
                  <td><button class="btn btn-sm btn-outline-primary" onclick='bukaKembali(<?= json_encode($a) ?>)'><i class="bi bi-box-arrow-in-left"></i> Kembalikan</button></td>
                </tr>
              <?php endwhile; endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL KONFIRMASI PENGEMBALIAN -->
<div class="modal fade" id="modalKembali" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST">
      <div class="modal-header"><h5 class="modal-title">Konfirmasi Pengembalian</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <input type="hidden" name="id_transaksi" id="id_transaksi">
        <p>Buku: <b id="judulBukuKembali"></b><br>Peminjam: <b id="namaSiswaKembali"></b></p>
        <div class="alert alert-warning small py-2"><i class="bi bi-shield-check"></i> Untuk keamanan, minta siswa menunjukkan kartu pelajar dan masukkan ulang NIS untuk konfirmasi.</div>
        <div class="mb-2">
          <label class="form-label">Konfirmasi NIS Siswa</label>
          <input type="text" name="nis_konfirmasi" class="form-control" required>
        </div>
        <div class="mb-2">
          <label class="form-label">Kondisi Buku Saat Dikembalikan</label>
          <select name="kondisi_buku" class="form-select" required>
            <option value="Baik">Baik</option>
            <option value="Rusak">Rusak (+Rp5.000)</option>
            <option value="Hilang">Hilang (+Rp50.000)</option>
          </select>
        </div>
        <p class="small text-muted mb-0">Denda keterlambatan otomatis dihitung Rp1.000/hari dari tanggal jatuh tempo.</p>
      </div>
      <div class="modal-footer"><button type="submit" name="proses_kembali" class="btn btn-primary w-100">Konfirmasi & Proses</button></div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
function bukaKembali(a) {
  document.getElementById('id_transaksi').value = a.id_transaksi;
  document.getElementById('judulBukuKembali').innerText = a.judul_buku;
  document.getElementById('namaSiswaKembali').innerText = a.nama + ' (' + a.nisn + ')';
  new bootstrap.Modal(document.getElementById('modalKembali')).show();
}
<?php if (isset($_POST['cari_nis']) && $siswaDitemukan): ?>
document.addEventListener('DOMContentLoaded', function() {
  new bootstrap.Tab(document.querySelector('[data-bs-target="#tabPinjam"]')).show();
});
<?php endif; ?>
</script>
</body>
</html>
