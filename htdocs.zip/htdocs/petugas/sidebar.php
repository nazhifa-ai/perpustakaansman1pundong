<?php $cur = basename($_SERVER['PHP_SELF']); ?>
<div class="sidebar" id="sidebarEl">
  <div class="brand" style="display: flex; align-items: center; gap: 10px; padding: 16px 12px;">
    <img src="../IMG/logo_sma.jpeg" alt="Logo SMAN 1 Pundong" style="height: 40px; width: 40px; object-fit: contain; border-radius: 4px; flex-shrink: 0;">
    <span style="font-size: 15px; font-weight: 600; line-height: 1.3;">Perpustakaan<br>SMAN 1 Pundong</span>
  </div>

  <div class="level-badge" style="margin: 0 12px 12px; padding: 8px 12px; background: rgba(255,255,255,.1); border-radius: 6px; display: flex; align-items: center; gap: 8px; font-size: 13px; color: #fff;">
    <i class="bi bi-person-workspace"></i>
    <span>Login sebagai <strong>Petugas</strong></span>
  </div>

  <nav class="nav flex-column py-2">
    <a class="nav-link <?= $cur=='dashboard.php'?'active':'' ?>" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a class="nav-link <?= $cur=='rak.php'?'active':'' ?>" href="rak.php"><i class="bi bi-bookshelf"></i> Atur &amp; Benarkan Rak</a>
    <a class="nav-link <?= $cur=='cek_kondisi.php'?'active':'' ?>" href="cek_kondisi.php"><i class="bi bi-clipboard2-check"></i> Cek Kondisi Buku</a>
    <a class="nav-link <?= $cur=='transaksi.php'?'active':'' ?>" href="transaksi.php"><i class="bi bi-arrow-left-right"></i> Transaksi</a>
    <hr class="mx-3" style="border-color: rgba(255,255,255,.15);">
    <a class="nav-link" href="logout.php" onclick="return confirmDelete('Yakin ingin logout?')"><i class="bi bi-box-arrow-right"></i> Logout</a>
  </nav>
</div>