<?php $cur = basename($_SERVER['PHP_SELF']); ?>
<div class="sidebar" id="sidebarEl">
  <div class="brand"><i class="bi bi-book-half me-2"></i>Perpus Petugas</div>
  <nav class="nav flex-column py-2">
    <a class="nav-link <?= $cur=='dashboard.php'?'active':'' ?>" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a class="nav-link <?= $cur=='rak.php'?'active':'' ?>" href="rak.php"><i class="bi bi-bookshelf"></i> Atur &amp; Benarkan Rak</a>
    <a class="nav-link <?= $cur=='cek_kondisi.php'?'active':'' ?>" href="cek_kondisi.php"><i class="bi bi-clipboard2-check"></i> Cek Kondisi Buku</a>
    <a class="nav-link <?= $cur=='transaksi.php'?'active':'' ?>" href="transaksi.php"><i class="bi bi-arrow-left-right"></i> Transaksi</a>
    <hr class="mx-3" style="border-color: rgba(255,255,255,.15);">
    <a class="nav-link" href="logout.php" onclick="return confirmDelete('Yakin ingin logout?')"><i class="bi bi-box-arrow-right"></i> Logout</a>
  </nav>
</div>
