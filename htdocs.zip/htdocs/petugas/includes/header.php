<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn btn-sm btn-light d-md-none" onclick="toggleSidebar()"><i class="bi bi-list"></i></button>
    <h5 class="mb-0 fw-bold"><?= $pageTitle ?? 'Dashboard' ?></h5>
  </div>
  <div class="d-flex align-items-center gap-2">
    <div class="bg-light rounded-circle d-flex align-items-center justify-content-center" style="width:36px;height:36px;">
      <i class="bi bi-person-workspace text-primary"></i>
    </div>
    <span class="fw-semibold small d-none d-sm-inline"><?= htmlspecialchars($_SESSION['nama'] ?? '') ?></span>
  </div>
</div>
