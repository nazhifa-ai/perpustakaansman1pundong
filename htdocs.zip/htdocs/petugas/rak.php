<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('petugas');
$pageTitle = "Atur & Benarkan Rak";
$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan_rak'])) {
    $id_buku    = (int) $_POST['id_buku'];
    $lokasi_rak = clean($conn, $_POST['lokasi_rak']);
    $stmt = mysqli_prepare($conn, "UPDATE buku SET lokasi_rak=? WHERE id_buku=?");
    mysqli_stmt_bind_param($stmt, "si", $lokasi_rak, $id_buku);
    mysqli_stmt_execute($stmt);
    $msg = "Lokasi rak buku berhasil diperbarui.";
}

$keyword = clean($conn, $_GET['q'] ?? '');
$data = mysqli_query($conn, "SELECT * FROM buku WHERE judul_buku LIKE '%$keyword%' OR kode_buku LIKE '%$keyword%' OR lokasi_rak LIKE '%$keyword%' ORDER BY lokasi_rak ASC, judul_buku ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <div class="card-panel">
      <p class="text-muted small">Gunakan halaman ini untuk mengatur ulang atau membenarkan penempatan buku pada rak perpustakaan.</p>
      <form class="d-flex mb-3" method="GET" style="max-width:320px;">
        <input type="text" name="q" class="form-control form-control-sm" placeholder="Cari buku / kode rak" value="<?= htmlspecialchars($keyword) ?>">
        <button class="btn btn-sm btn-primary ms-1"><i class="bi bi-search"></i></button>
      </form>
      <div class="table-responsive">
        <table class="table align-middle table-hover">
          <thead><tr><th>Kode</th><th>Judul Buku</th><th>Kategori</th><th>Lokasi Rak Saat Ini</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($data) === 0): ?>
            <tr><td colspan="5" class="text-center text-muted">Tidak ada data buku.</td></tr>
          <?php else: while ($b = mysqli_fetch_assoc($data)): ?>
            <tr>
              <td><?= htmlspecialchars($b['kode_buku']) ?></td>
              <td><?= htmlspecialchars($b['judul_buku']) ?></td>
              <td><?= htmlspecialchars($b['kategori']) ?></td>
              <td><span class="badge bg-secondary"><?= htmlspecialchars($b['lokasi_rak'] ?: 'Belum diatur') ?></span></td>
              <td>
                <button class="btn btn-sm btn-outline-primary" onclick='ubahRak(<?= json_encode($b) ?>)'><i class="bi bi-arrow-repeat"></i> Ubah Rak</button>
              </td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="modalRak" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST">
      <div class="modal-header"><h5 class="modal-title">Ubah Lokasi Rak</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <input type="hidden" name="id_buku" id="id_buku">
        <p class="mb-1">Buku: <b id="judulBuku"></b></p>
        <label class="form-label">Lokasi Rak Baru</label>
        <input type="text" name="lokasi_rak" id="lokasi_rak" class="form-control" placeholder="Contoh: Rak B2" required>
      </div>
      <div class="modal-footer"><button type="submit" name="simpan_rak" class="btn btn-primary w-100">Simpan</button></div>
    </form>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
function ubahRak(b) {
  document.getElementById('id_buku').value = b.id_buku;
  document.getElementById('judulBuku').innerText = b.judul_buku;
  document.getElementById('lokasi_rak').value = b.lokasi_rak || '';
  new bootstrap.Modal(document.getElementById('modalRak')).show();
}
</script>
</body>
</html>
