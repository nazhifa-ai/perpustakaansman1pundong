<?php
/**
 * Helper umum yang dipakai di seluruh aplikasi
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
function clean($conn, $data) {
    return mysqli_real_escape_string($conn, trim($data));
}
/** Wajib login dengan role tertentu, kalau tidak redirect ke login */
function requireRole($role) {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== $role) {
        header("Location: ../login.php?role=$role");
        exit;
    }
}
/** Format tanggal Indonesia: 1 Januari 2026 */
function formatTanggal($tgl) {
    if (!$tgl) return "-";
    $bulan = ["", "Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
    $d = date("d", strtotime($tgl));
    $m = (int) date("n", strtotime($tgl));
    $y = date("Y", strtotime($tgl));
    return "$d " . $bulan[$m] . " $y";
}
/** Hitung denda keterlambatan. Rp1.000 / hari terlambat */
function hitungDenda($tanggal_jatuh_tempo, $tanggal_kembali) {
    $jatuh_tempo = new DateTime($tanggal_jatuh_tempo);
    $kembali = new DateTime($tanggal_kembali);
    if ($kembali <= $jatuh_tempo) return 0;
    $selisih = $jatuh_tempo->diff($kembali)->days;
    return $selisih * 1000;
}
function rupiah($angka) {
    return "Rp " . number_format((float)$angka, 0, ',', '.');
}
/** Badge status transaksi/kondisi buku */
function badge($status) {
    $map = [
        'Dipinjam'     => 'warning text-dark',
        'Dikembalikan' => 'success',
        'Tersedia'     => 'success',
        'Habis'        => 'danger',
        'Baik'         => 'success',
        'Rusak'        => 'warning text-dark',
        'Hilang'       => 'danger',
    ];
    $cls = $map[$status] ?? 'secondary';
    return "<span class='badge bg-$cls'>" . htmlspecialchars($status) . "</span>";
}

/** Render tampilan bintang berdasarkan rating (mendukung desimal, misal 3.5) */
function renderBintang($rating, $size = '1rem') {
    $rating = round($rating * 2) / 2; // pembulatan ke 0.5 terdekat
    $html = '<span style="color:#f4a52a; font-size:' . $size . ';">';
    for ($i = 1; $i <= 5; $i++) {
        if ($rating >= $i) {
            $html .= '<i class="bi bi-star-fill"></i>';
        } elseif ($rating >= $i - 0.5) {
            $html .= '<i class="bi bi-star-half"></i>';
        } else {
            $html .= '<i class="bi bi-star"></i>';
        }
    }
    $html .= '</span>';
    return $html;
}

/** Ambil rata-rata rating dan jumlah ulasan untuk satu buku */
function getRatingBuku($conn, $id_buku) {
    $q = mysqli_query($conn, "SELECT AVG(rating) AS rata, COUNT(*) AS jml FROM ulasan WHERE id_buku=" . (int)$id_buku);
    $r = mysqli_fetch_assoc($q);
    return [
        'rata' => $r['rata'] ? round($r['rata'], 1) : 0,
        'jml'  => (int) $r['jml']
    ];
}