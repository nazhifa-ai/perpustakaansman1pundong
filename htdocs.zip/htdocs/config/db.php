<?php
/**
 * KONEKSI DATABASE
 * ------------------------------------------------------
 * GANTI 4 nilai di bawah ini sesuai data database InfinityFree
 * kamu (lihat di menu MySQL Databases pada cPanel InfinityFree).
 * Contoh berdasarkan phpMyAdmin yang kamu pakai:
 *   host : sql106.byetcluster.com
 *   user : if0_42790396          (biasanya sama dgn nama akun)
 *   db   : if0_42790396_perpustakaan_sma
 *   pass : (password database kamu)
 * ------------------------------------------------------
 */
$DB_HOST = "sql106.byetcluster.com";
$DB_USER = "if0_42790396";
$DB_PASS = "CPdpBjTG685";
$DB_NAME = "if0_42790396_perpustakaan_sma";

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8mb4");
