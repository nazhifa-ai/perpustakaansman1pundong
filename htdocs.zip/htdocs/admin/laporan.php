<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('admin');
$pageTitle = "Laporan";
$kategoriQ = mysqli_query($conn, "SELECT kategori, COUNT(*) jml FROM buku GROUP BY kategori");
$kategoriData = []; while ($r = mysqli_fetch_assoc($kategoriQ)) $kategoriData[] = $r;
$bulanQ = mysqli_query($conn, "
  SELECT DATE_FORMAT(tanggal_pinjam, '%Y-%m') bln, COUNT(*) jml
  FROM transaksi GROUP BY bln ORDER BY bln ASC LIMIT 12
");
$bulanData = []; while ($r = mysqli_fetch_assoc($bulanQ)) $bulanData[] = $r;
$totalDenda = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(denda),0) t FROM pengembalian"))['t'];
$bukuRusak  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM buku WHERE kondisi != 'Baik'"))['c'];
$labelsK = json_encode(array_column($kategoriData, 'kategori'));
$valuesK = json_encode(array_map('intval', array_column($kategoriData, 'jml')));
$labelsB = json_encode(array_column($bulanData, 'bln'));
$valuesB = json_encode(array_map('intval', array_column($bulanData, 'jml')));

// total buku untuk kolom persentase di tabel cetak
$totalBuku = array_sum(array_column($kategoriData, 'jml'));

// nama bulan Indonesia untuk tabel cetak
$namaBulan = [
  '01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April',
  '05'=>'Mei','06'=>'Juni','07'=>'Juli','08'=>'Agustus',
  '09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'
];
function formatBulan($bln, $namaBulan) {
  [$y, $m] = explode('-', $bln);
  return ($namaBulan[$m] ?? $m) . ' ' . $y;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
<style>
  /* ===== Kontrol ukuran grafik agar tidak membesar sendiri ===== */
  .chart-container {
    position: relative;
    width: 100%;
    height: 280px;
  }
  .chart-container.chart-donut {
    max-width: 280px;
    margin: 0 auto;
  }

  /* Header aksi di atas (judul + tombol cetak) */
  .laporan-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 16px;
  }

  /* ===== Tampilan cetak: dokumen, bukan diagram ===== */
  .print-only { display: none; }

  @media print {
    /* Sembunyikan elemen layar yang tidak perlu saat dicetak */
    .sb-sidebar, #sidebar, .sidebar,
    header, .content-header, .btn, .laporan-topbar,
    .card-panel canvas, .screen-only {
      display: none !important;
    }

    /* Tampilkan versi dokumen (tabel) hanya saat print */
    .print-only { display: block !important; }

    body {
      background: #fff !important;
      color: #000 !important;
    }
    .content-area {
      margin: 0 !important;
      padding: 0 !important;
      width: 100% !important;
    }
    .sb-wrapper {
      display: block !important;
    }

    .print-header {
      text-align: center;
      border-bottom: 2px solid #000;
      padding-bottom: 10px;
      margin-bottom: 20px;
    }
    .print-header h4 { margin: 0; font-weight: 700; }
    .print-header small { display: block; margin-top: 4px; }

    .print-section-title {
      font-weight: 700;
      margin-top: 20px;
      margin-bottom: 8px;
      border-bottom: 1px solid #333;
      padding-bottom: 4px;
    }

    table.print-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 13px;
    }
    table.print-table th, table.print-table td {
      border: 1px solid #333;
      padding: 6px 8px;
    }
    table.print-table th {
      background: #eee !important;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    .print-summary {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      font-size: 14px;
    }
    .print-summary div { border: 1px solid #333; padding: 10px 16px; }

    .print-footer {
      margin-top: 40px;
      display: flex;
      justify-content: flex-end;
      font-size: 13px;
    }
    .print-footer .ttd { text-align: center; width: 220px; }
    .print-footer .ttd .space { height: 70px; }
  }
</style>
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>

    <!-- ===== Tampilan layar (screen only) ===== -->
    <div class="screen-only">

      <!-- Tombol cetak sekarang hanya ada di atas -->
      <div class="laporan-topbar">
        <h5 class="fw-bold mb-0">Ringkasan Laporan</h5>
        <button class="btn btn-outline-secondary btn-sm" onclick="window.print()">
          <i class="bi bi-printer"></i> Cetak Laporan
        </button>
      </div>

      <div class="row g-3 mb-3">
        <div class="col-6 col-md-4">
          <div class="stat-card"><div class="num"><?= rupiah($totalDenda) ?></div><small class="text-muted">Total Denda Terkumpul</small></div>
        </div>
        <div class="col-6 col-md-4">
          <div class="stat-card"><div class="num"><?= $bukuRusak ?></div><small class="text-muted">Buku Rusak/Hilang</small></div>
        </div>
      </div>
      <div class="row g-3">
        <div class="col-lg-6">
          <div class="card-panel">
            <h6 class="fw-bold mb-3">Koleksi Buku per Kategori</h6>
            <div class="chart-container chart-donut">
              <canvas id="chartKategori"></canvas>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="card-panel">
            <h6 class="fw-bold mb-3">Peminjaman per Bulan</h6>
            <div class="chart-container">
              <canvas id="chartBulan"></canvas>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== Tampilan cetak (print only): dokumen laporan ===== -->
    <div class="print-only">
      <div class="print-header">
        <h4>LAPORAN PERPUSTAKAAN</h4>
        <small>SMA Negeri 1 Pundong</small>
        <small>Dicetak pada: <?= date('d F Y, H:i') ?> WIB</small>
      </div>

      <div class="print-summary">
        <div><strong>Total Denda Terkumpul:</strong> <?= rupiah($totalDenda) ?></div>
        <div><strong>Buku Rusak/Hilang:</strong> <?= $bukuRusak ?> buku</div>
      </div>

      <div class="print-section-title">Koleksi Buku per Kategori</div>
      <table class="print-table">
        <thead>
          <tr>
            <th style="width:50px;">No</th>
            <th>Kategori</th>
            <th style="width:120px;">Jumlah Buku</th>
            <th style="width:120px;">Persentase</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($kategoriData)): ?>
            <tr><td colspan="4" class="text-center">Tidak ada data</td></tr>
          <?php else: $no = 1; foreach ($kategoriData as $row): ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><?= htmlspecialchars($row['kategori']) ?></td>
              <td><?= $row['jml'] ?></td>
              <td><?= $totalBuku > 0 ? round($row['jml'] / $totalBuku * 100, 1) : 0 ?>%</td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
        <?php if (!empty($kategoriData)): ?>
        <tfoot>
          <tr>
            <th colspan="2">Total</th>
            <th><?= $totalBuku ?></th>
            <th>100%</th>
          </tr>
        </tfoot>
        <?php endif; ?>
      </table>

      <div class="print-section-title">Peminjaman per Bulan</div>
      <table class="print-table">
        <thead>
          <tr>
            <th style="width:50px;">No</th>
            <th>Bulan</th>
            <th style="width:150px;">Jumlah Peminjaman</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($bulanData)): ?>
            <tr><td colspan="3" class="text-center">Tidak ada data</td></tr>
          <?php else: $no = 1; foreach ($bulanData as $row): ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><?= formatBulan($row['bln'], $namaBulan) ?></td>
              <td><?= $row['jml'] ?></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>

      <div class="print-footer">
        <div class="ttd">
          <div>Yogyakarta, <?= date('d F Y') ?></div>
          <div>Petugas Perpustakaan</div>
          <div class="space"></div>
          <div>( _________________________ )</div>
        </div>
      </div>
    </div>

  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
new Chart(document.getElementById('chartKategori'), {
  type: 'doughnut',
  data: { labels: <?= $labelsK ?: '[]' ?>, datasets: [{ data: <?= $valuesK ?: '[]' ?>, backgroundColor: ['#2653a3','#f4a52a','#2a9d5c','#e0402c','#7c5cbf','#17a2b8'] }] },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { position: 'bottom' } }
  }
});
new Chart(document.getElementById('chartBulan'), {
  type: 'line',
  data: { labels: <?= $labelsB ?: '[]' ?>, datasets: [{ label: 'Peminjaman', data: <?= $valuesB ?: '[]' ?>, borderColor: '#2653a3', tension: .3, fill:false }] },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
  }
});
</script>
</body>
</html>