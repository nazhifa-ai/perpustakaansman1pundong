<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('admin');
$pageTitle = "Data Anggota (Siswa)";
$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $id_siswa = $_POST['id_siswa'] ?? '';
    $nisn     = clean($conn, $_POST['nisn']);
    $nama     = clean($conn, $_POST['nama']);
    $username = clean($conn, $_POST['username']);
    $kelas    = clean($conn, $_POST['kelas']);
    $jurusan  = clean($conn, $_POST['jurusan']);
    $no_telp  = clean($conn, $_POST['no_telp']);
    $alamat   = clean($conn, $_POST['alamat']);
    $password = $_POST['password'];

    if ($id_siswa === '') {
        $hash = password_hash($password !== '' ? $password : 'siswa123', PASSWORD_BCRYPT);
        $stmt = mysqli_prepare($conn, "INSERT INTO siswa (nisn, nama, username, password, kelas, jurusan, no_telp, alamat) VALUES (?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, "ssssssss", $nisn, $nama, $username, $hash, $kelas, $jurusan, $no_telp, $alamat);
        mysqli_stmt_execute($stmt);
        $msg = "Anggota baru berhasil ditambahkan.";
    } else {
        if ($password !== '') {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = mysqli_prepare($conn, "UPDATE siswa SET nisn=?, nama=?, username=?, password=?, kelas=?, jurusan=?, no_telp=?, alamat=? WHERE id_siswa=?");
            mysqli_stmt_bind_param($stmt, "ssssssssi", $nisn, $nama, $username, $hash, $kelas, $jurusan, $no_telp, $alamat, $id_siswa);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE siswa SET nisn=?, nama=?, username=?, kelas=?, jurusan=?, no_telp=?, alamat=? WHERE id_siswa=?");
            mysqli_stmt_bind_param($stmt, "sssssssi", $nisn, $nama, $username, $kelas, $jurusan, $no_telp, $alamat, $id_siswa);
        }
        mysqli_stmt_execute($stmt);
        $msg = "Data anggota berhasil diperbarui.";
    }
}

if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM siswa WHERE id_siswa=$id");
    $msg = "Anggota berhasil dihapus.";
}

$keyword = clean($conn, $_GET['q'] ?? '');
$data = mysqli_query($conn, "SELECT * FROM siswa WHERE nama LIKE '%$keyword%' OR nisn LIKE '%$keyword%' OR username LIKE '%$keyword%' ORDER BY id_siswa DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <div class="card-panel">
      <div class="d-flex justify-content-between flex-wrap gap-2 mb-3">
        <form class="d-flex" method="GET" style="max-width:300px;">
          <input type="text" name="q" class="form-control form-control-sm" placeholder="Cari nama/NISN/username" value="<?= htmlspecialchars($keyword) ?>">
          <button class="btn btn-sm btn-primary ms-1"><i class="bi bi-search"></i></button>
        </form>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalSiswa" onclick="resetForm()"><i class="bi bi-plus-lg"></i> Tambah Anggota</button>
      </div>
      <div class="table-responsive">
        <table class="table align-middle table-hover">
          <thead><tr><th>NISN</th><th>Nama</th><th>Username</th><th>Kelas</th><th>Jurusan</th><th>No. Telp</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($data) === 0): ?>
            <tr><td colspan="7" class="text-center text-muted">Belum ada data anggota.</td></tr>
          <?php else: while ($s = mysqli_fetch_assoc($data)): ?>
            <tr>
              <td><?= htmlspecialchars($s['nisn']) ?></td>
              <td><?= htmlspecialchars($s['nama']) ?></td>
              <td><?= htmlspecialchars($s['username']) ?></td>
              <td><?= htmlspecialchars($s['kelas']) ?></td>
              <td><?= htmlspecialchars($s['jurusan']) ?></td>
              <td><?= htmlspecialchars($s['no_telp']) ?></td>
              <td class="text-nowrap">
                <button class="btn btn-sm btn-outline-warning" onclick='editSiswa(<?= json_encode($s) ?>)'><i class="bi bi-pencil"></i></button>
                <a class="btn btn-sm btn-outline-danger" href="?hapus=<?= $s['id_siswa'] ?>" onclick="return confirmDelete('Hapus anggota ini?')"><i class="bi bi-trash"></i></a>
              </td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="modalSiswa" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST">
      <div class="modal-header"><h5 class="modal-title" id="modalTitle">Tambah Anggota</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <input type="hidden" name="id_siswa" id="id_siswa">
        <div class="row">
          <div class="col-6 mb-2"><label class="form-label">NISN</label><input type="text" name="nisn" id="nisn" class="form-control" required></div>
          <div class="col-6 mb-2"><label class="form-label">Username</label><input type="text" name="username" id="username" class="form-control" required></div>
        </div>
        <div class="mb-2"><label class="form-label">Nama Lengkap</label><input type="text" name="nama" id="nama" class="form-control" required></div>
        <div class="row">
          <div class="col-6 mb-2"><label class="form-label">Kelas</label><input type="text" name="kelas" id="kelas" class="form-control"></div>
          <div class="col-6 mb-2"><label class="form-label">Jurusan</label><input type="text" name="jurusan" id="jurusan" class="form-control"></div>
        </div>
        <div class="mb-2"><label class="form-label">No. Telepon</label><input type="text" name="no_telp" id="no_telp" class="form-control"></div>
        <div class="mb-2"><label class="form-label">Alamat</label><textarea name="alamat" id="alamat" class="form-control" rows="2"></textarea></div>
        <div class="mb-2"><label class="form-label">Password <small class="text-muted">(kosongkan jika tidak diubah, default: siswa123)</small></label><input type="password" name="password" id="password" class="form-control"></div>
      </div>
      <div class="modal-footer"><button type="submit" name="simpan" class="btn btn-primary w-100">Simpan</button></div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
function resetForm() {
  document.getElementById('modalTitle').innerText = 'Tambah Anggota';
  document.querySelectorAll('#modalSiswa input, #modalSiswa textarea').forEach(i => i.value = '');
}
function editSiswa(s) {
  document.getElementById('modalTitle').innerText = 'Edit Anggota';
  document.getElementById('id_siswa').value = s.id_siswa;
  document.getElementById('nisn').value = s.nisn;
  document.getElementById('username').value = s.username;
  document.getElementById('nama').value = s.nama;
  document.getElementById('kelas').value = s.kelas;
  document.getElementById('jurusan').value = s.jurusan;
  document.getElementById('no_telp').value = s.no_telp;
  document.getElementById('alamat').value = s.alamat;
  document.getElementById('password').value = '';
  new bootstrap.Modal(document.getElementById('modalSiswa')).show();
}
</script>
</body>
</html>
