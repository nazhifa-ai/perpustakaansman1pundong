<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('admin');
$pageTitle = "Data Transaksi";
$msg = "";

// Tarif denda per hari keterlambatan (sesuaikan dengan kebijakan perpustakaan)
$DENDA_PER_HARI = 1000;

// TAMBAH TRANSAKSI MANUAL (opsional oleh admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $id_anggota = (int) $_POST['id_anggota'];
    $id_buku    = (int) $_POST['id_buku'];
    $lama       = (int) $_POST['lama_hari'];
    $tgl_pinjam = date('Y-m-d');
    $jatuh_tempo = date('Y-m-d', strtotime("+$lama days"));

    $cek = mysqli_query($conn, "SELECT buku_tersedia FROM buku WHERE id_buku=$id_buku");
    $b = mysqli_fetch_assoc($cek);
    if ($b && $b['buku_tersedia'] > 0) {
        $stmt = mysqli_prepare($conn, "INSERT INTO transaksi (id_anggota, id_buku, tanggal_pinjam, tanggal_jatuh_tempo, status) VALUES (?,?,?,?,'Dipinjam')");
        mysqli_stmt_bind_param($stmt, "iiss", $id_anggota, $id_buku, $tgl_pinjam, $jatuh_tempo);
        mysqli_stmt_execute($stmt);
        mysqli_query($conn, "UPDATE buku SET buku_tersedia = buku_tersedia - 1 WHERE id_buku=$id_buku");
        $msg = "Transaksi peminjaman berhasil dicatat.";
    } else {
        $msg = "Stok buku tidak tersedia.";
    }
}

if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM transaksi WHERE id_transaksi=$id");
    $msg = "Transaksi berhasil dihapus.";
}

$filter = $_GET['status'] ?? 'Semua';
$where = $filter !== 'Semua' ? "WHERE t.status='" . clean($conn, $filter) . "'" : "";

// LEFT JOIN ke pengembalian untuk ambil denda aktual jika sudah dikembalikan
$data = mysqli_query($conn, "
  SELECT t.*, b.judul_buku, s.nama, s.nisn, p.denda AS denda_aktual, p.tanggal_kembali
  FROM transaksi t
  JOIN buku b ON b.id_buku=t.id_buku
  JOIN siswa s ON s.id_siswa=t.id_anggota
  LEFT JOIN pengembalian p ON p.id_transaksi = t.id_transaksi
  $where ORDER BY t.id_transaksi DESC
");
$listSiswa = mysqli_query($conn, "SELECT id_siswa, nama, nisn FROM siswa ORDER BY nama");
$listBuku  = mysqli_query($conn, "SELECT id_buku, judul_buku, buku_tersedia FROM buku WHERE buku_tersedia > 0 ORDER BY judul_buku");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-info"><?= $msg ?></div><?php endif; ?>
    <div class="card-panel">
      <div class="d-flex justify-content-between flex-wrap gap-2 mb-3">
        <div class="btn-group">
          <a class="btn btn-sm btn-outline-secondary <?= $filter=='Semua'?'active':'' ?>" href="?status=Semua">Semua</a>
          <a class="btn btn-sm btn-outline-secondary <?= $filter=='Dipinjam'?'active':'' ?>" href="?status=Dipinjam">Dipinjam</a>
          <a class="btn btn-sm btn-outline-secondary <?= $filter=='Dikembalikan'?'active':'' ?>" href="?status=Dikembalikan">Dikembalikan</a>
        </div>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalTransaksi"><i class="bi bi-plus-lg"></i> Catat Peminjaman</button>
      </div>
      <div class="table-responsive">
        <table class="table align-middle table-hover">
          <thead><tr><th>Siswa</th><th>NISN</th><th>Buku</th><th>Tgl Pinjam</th><th>Jatuh Tempo</th><th>Status</th><th>Denda</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($data) === 0): ?>
            <tr><td colspan="8" class="text-center text-muted">Tidak ada transaksi.</td></tr>
          <?php else: while ($t = mysqli_fetch_assoc($data)): ?>
            <?php
              // Hitung tampilan denda
              $dendaTampil = '<span class="text-muted">-</span>';
              if ($t['status'] === 'Dikembalikan') {
                  $nilaiDenda = (float) ($t['denda_aktual'] ?? 0);
                  if ($nilaiDenda > 0) {
                      $dendaTampil = '<span class="text-danger fw-semibold">' . rupiah($nilaiDenda) . '</span>';
                  } else {
                      $dendaTampil = '<span class="text-success">Rp 0</span>';
                  }
              } elseif ($t['status'] === 'Dipinjam') {
                  $hariIni = new DateTime(date('Y-m-d'));
                  $jatuhTempo = new DateTime($t['tanggal_jatuh_tempo']);
                  if ($hariIni > $jatuhTempo) {
                      $telat = $hariIni->diff($jatuhTempo)->days;
                      $estimasi = $telat * $DENDA_PER_HARI;
                      $dendaTampil = '<span class="text-danger">' . rupiah($estimasi) . '</span><br><small class="text-muted">Terlambat ' . $telat . ' hari (berjalan)</small>';
                  }
              }
            ?>
            <tr>
              <td><?= htmlspecialchars($t['nama']) ?></td>
              <td><?= htmlspecialchars($t['nisn']) ?></td>
              <td><?= htmlspecialchars($t['judul_buku']) ?></td>
              <td><?= formatTanggal($t['tanggal_pinjam']) ?></td>
              <td><?= formatTanggal($t['tanggal_jatuh_tempo']) ?></td>
              <td><?= badge($t['status']) ?></td>
              <td><?= $dendaTampil ?></td>
              <td><a class="btn btn-sm btn-outline-danger" href="?hapus=<?= $t['id_transaksi'] ?>" onclick="return confirmDelete('Hapus transaksi ini?')"><i class="bi bi-trash"></i></a></td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="modalTransaksi" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST">
      <div class="modal-header"><h5 class="modal-title">Catat Peminjaman Buku</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <div class="mb-2">
          <label class="form-label">Siswa</label>
          <select name="id_anggota" class="form-select" required>
            <?php mysqli_data_seek($listSiswa, 0); while ($s = mysqli_fetch_assoc($listSiswa)): ?>
              <option value="<?= $s['id_siswa'] ?>"><?= htmlspecialchars($s['nama']) ?> (<?= htmlspecialchars($s['nisn']) ?>)</option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="mb-2">
          <label class="form-label">Buku</label>
          <select name="id_buku" class="form-select" required>
            <?php mysqli_data_seek($listBuku, 0); while ($b = mysqli_fetch_assoc($listBuku)): ?>
              <option value="<?= $b['id_buku'] ?>"><?= htmlspecialchars($b['judul_buku']) ?> (tersisa <?= $b['buku_tersedia'] ?>)</option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="mb-2">
          <label class="form-label">Lama Peminjaman (hari)</label>
          <input type="number" name="lama_hari" class="form-control" value="7" min="1" required>
        </div>
      </div>
      <div class="modal-footer"><button type="submit" name="simpan" class="btn btn-primary w-100">Simpan</button></div>
    </form>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
</body>
</html>