<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('admin');
$pageTitle = "Data Pengembalian";

$data = mysqli_query($conn, "
  SELECT p.*, t.tanggal_pinjam, t.tanggal_jatuh_tempo, b.judul_buku, s.nama, s.nisn
  FROM pengembalian p
  JOIN transaksi t ON t.id_transaksi = p.id_transaksi
  JOIN buku b ON b.id_buku = t.id_buku
  JOIN siswa s ON s.id_siswa = t.id_anggota
  ORDER BY p.id_pengembalian DESC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <div class="card-panel">
      <p class="text-muted small mb-3">Riwayat pengembalian buku dicatat oleh Petugas melalui menu Transaksi.</p>
      <div class="table-responsive">
        <table class="table align-middle table-hover">
          <thead><tr><th>Siswa</th><th>NISN</th><th>Buku</th><th>Tgl Pinjam</th><th>Tgl Kembali</th><th>Kondisi</th><th>Denda</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($data) === 0): ?>
            <tr><td colspan="7" class="text-center text-muted">Belum ada data pengembalian.</td></tr>
          <?php else: while ($p = mysqli_fetch_assoc($data)): ?>
            <tr>
              <td><?= htmlspecialchars($p['nama']) ?></td>
              <td><?= htmlspecialchars($p['nisn']) ?></td>
              <td><?= htmlspecialchars($p['judul_buku']) ?></td>
              <td><?= formatTanggal($p['tanggal_pinjam']) ?></td>
              <td><?= formatTanggal($p['tanggal_kembali']) ?></td>
              <td><?= badge($p['kondisi_buku']) ?></td>
              <td><?= rupiah($p['denda']) ?></td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
</body>
</html>
