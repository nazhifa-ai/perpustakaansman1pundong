<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('admin');
$pageTitle = "Data Buku";
$msg = "";

// TAMBAH / EDIT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $id_buku    = $_POST['id_buku'] ?? '';
    $kode_buku  = clean($conn, $_POST['kode_buku']);
    $judul_buku = clean($conn, $_POST['judul_buku']);
    $kategori   = clean($conn, $_POST['kategori']);
    $penulis    = clean($conn, $_POST['penulis']);
    $penerbit   = clean($conn, $_POST['penerbit']);
    $tahun      = (int) $_POST['tahun'];
    $jumlah     = (int) $_POST['jumlah'];
    $lokasi_rak = clean($conn, $_POST['lokasi_rak']);

    if ($id_buku === '') {
        $stmt = mysqli_prepare($conn, "INSERT INTO buku (kode_buku, judul_buku, kategori, penulis, penerbit, tahun, status, jumlah, buku_tersedia, lokasi_rak, kondisi) VALUES (?,?,?,?,?,?,'Tersedia',?,?,?,'Baik')");
        mysqli_stmt_bind_param($stmt, "sssssiiis", $kode_buku, $judul_buku, $kategori, $penulis, $penerbit, $tahun, $jumlah, $jumlah, $lokasi_rak);
        mysqli_stmt_execute($stmt);
        $msg = "Buku baru berhasil ditambahkan.";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE buku SET kode_buku=?, judul_buku=?, kategori=?, penulis=?, penerbit=?, tahun=?, jumlah=?, lokasi_rak=? WHERE id_buku=?");
        mysqli_stmt_bind_param($stmt, "sssssiisi", $kode_buku, $judul_buku, $kategori, $penulis, $penerbit, $tahun, $jumlah, $lokasi_rak, $id_buku);
        mysqli_stmt_execute($stmt);
        $msg = "Data buku berhasil diperbarui.";
    }
}

// HAPUS
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM buku WHERE id_buku=$id");
    $msg = "Buku berhasil dihapus.";
}

$keyword = clean($conn, $_GET['q'] ?? '');
$sql = "SELECT * FROM buku WHERE judul_buku LIKE '%$keyword%' OR kode_buku LIKE '%$keyword%' OR kategori LIKE '%$keyword%' ORDER BY id_buku DESC";
$dataBuku = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>

    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>

    <div class="card-panel">
      <div class="d-flex justify-content-between flex-wrap gap-2 mb-3">
        <form class="d-flex" method="GET" style="max-width:300px;">
          <input type="text" name="q" class="form-control form-control-sm" placeholder="Cari judul/kode/kategori" value="<?= htmlspecialchars($keyword) ?>">
          <button class="btn btn-sm btn-primary ms-1"><i class="bi bi-search"></i></button>
        </form>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalBuku" onclick="resetForm()"><i class="bi bi-plus-lg"></i> Tambah Buku</button>
      </div>
      <div class="table-responsive">
        <table class="table align-middle table-hover">
          <thead><tr><th>Kode</th><th>Judul</th><th>Kategori</th><th>Penulis</th><th>Tahun</th><th>Stok</th><th>Tersedia</th><th>Rak</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($dataBuku) === 0): ?>
            <tr><td colspan="10" class="text-center text-muted">Tidak ada data buku.</td></tr>
          <?php else: while ($b = mysqli_fetch_assoc($dataBuku)): ?>
            <tr>
              <td><?= htmlspecialchars($b['kode_buku']) ?></td>
              <td><?= htmlspecialchars($b['judul_buku']) ?></td>
              <td><?= htmlspecialchars($b['kategori']) ?></td>
              <td><?= htmlspecialchars($b['penulis']) ?></td>
              <td><?= htmlspecialchars($b['tahun']) ?></td>
              <td><?= $b['jumlah'] ?></td>
              <td><?= $b['buku_tersedia'] ?></td>
              <td><?= htmlspecialchars($b['lokasi_rak']) ?></td>
              <td><?= badge($b['buku_tersedia'] > 0 ? 'Tersedia' : 'Habis') ?></td>
              <td class="text-nowrap">
                <button class="btn btn-sm btn-outline-warning" onclick='editBuku(<?= json_encode($b) ?>)'><i class="bi bi-pencil"></i></button>
                <a class="btn btn-sm btn-outline-danger" href="?hapus=<?= $b['id_buku'] ?>" onclick="return confirmDelete('Hapus buku ini?')"><i class="bi bi-trash"></i></a>
              </td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- MODAL TAMBAH/EDIT -->
<div class="modal fade" id="modalBuku" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST">
      <div class="modal-header"><h5 class="modal-title" id="modalTitle">Tambah Buku</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <input type="hidden" name="id_buku" id="id_buku">
        <div class="mb-2"><label class="form-label">Kode Buku</label><input type="text" name="kode_buku" id="kode_buku" class="form-control" required></div>
        <div class="mb-2"><label class="form-label">Judul Buku</label><input type="text" name="judul_buku" id="judul_buku" class="form-control" required></div>
        <div class="row">
          <div class="col-6 mb-2"><label class="form-label">Kategori</label><input type="text" name="kategori" id="kategori" class="form-control" required></div>
          <div class="col-6 mb-2"><label class="form-label">Tahun</label><input type="number" name="tahun" id="tahun" class="form-control"></div>
        </div>
        <div class="mb-2"><label class="form-label">Penulis</label><input type="text" name="penulis" id="penulis" class="form-control" required></div>
        <div class="mb-2"><label class="form-label">Penerbit</label><input type="text" name="penerbit" id="penerbit" class="form-control"></div>
        <div class="row">
          <div class="col-6 mb-2"><label class="form-label">Jumlah Eksemplar</label><input type="number" name="jumlah" id="jumlah" class="form-control" min="0" required></div>
          <div class="col-6 mb-2"><label class="form-label">Lokasi Rak</label><input type="text" name="lokasi_rak" id="lokasi_rak" class="form-control" placeholder="Rak A1"></div>
        </div>
      </div>
      <div class="modal-footer"><button type="submit" name="simpan" class="btn btn-primary w-100">Simpan</button></div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
function resetForm() {
  document.getElementById('modalTitle').innerText = 'Tambah Buku';
  document.querySelectorAll('#modalBuku input').forEach(i => i.value = '');
}
function editBuku(b) {
  document.getElementById('modalTitle').innerText = 'Edit Buku';
  document.getElementById('id_buku').value = b.id_buku;
  document.getElementById('kode_buku').value = b.kode_buku;
  document.getElementById('judul_buku').value = b.judul_buku;
  document.getElementById('kategori').value = b.kategori;
  document.getElementById('tahun').value = b.tahun;
  document.getElementById('penulis').value = b.penulis;
  document.getElementById('penerbit').value = b.penerbit;
  document.getElementById('jumlah').value = b.jumlah;
  document.getElementById('lokasi_rak').value = b.lokasi_rak;
  new bootstrap.Modal(document.getElementById('modalBuku')).show();
}
</script>
</body>
</html>
