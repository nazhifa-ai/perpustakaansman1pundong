<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('admin');
$pageTitle = "Kelola Admin";
$level = 'admin';
$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $id       = $_POST['id'] ?? '';
    $nama     = clean($conn, $_POST['nama']);
    $username = clean($conn, $_POST['username']);
    $no_telp  = clean($conn, $_POST['no_telp']);
    $alamat   = clean($conn, $_POST['alamat']);
    $password = $_POST['password'];

    if ($id === '') {
        $hash = password_hash($password !== '' ? $password : 'admin123', PASSWORD_BCRYPT);
        $stmt = mysqli_prepare($conn, "INSERT INTO admin (nama, username, password, level, no_telp, alamat) VALUES (?,?,?,'admin',?,?)");
        mysqli_stmt_bind_param($stmt, "sssss", $nama, $username, $hash, $no_telp, $alamat);
        mysqli_stmt_execute($stmt);
        $msg = "Admin baru berhasil ditambahkan.";
    } else {
        if ($password !== '') {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = mysqli_prepare($conn, "UPDATE admin SET nama=?, username=?, password=?, no_telp=?, alamat=? WHERE id=? AND level='admin'");
            mysqli_stmt_bind_param($stmt, "sssssi", $nama, $username, $hash, $no_telp, $alamat, $id);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE admin SET nama=?, username=?, no_telp=?, alamat=? WHERE id=? AND level='admin'");
            mysqli_stmt_bind_param($stmt, "ssssi", $nama, $username, $no_telp, $alamat, $id);
        }
        mysqli_stmt_execute($stmt);
        $msg = "Data admin berhasil diperbarui.";
    }
}

if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    if ($id === (int) $_SESSION['id']) {
        $msg = "Tidak dapat menghapus akun yang sedang login.";
    } else {
        mysqli_query($conn, "DELETE FROM admin WHERE id=$id AND level='admin'");
        $msg = "Admin berhasil dihapus.";
    }
}

$data = mysqli_query($conn, "SELECT * FROM admin WHERE level='admin' ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <div class="card-panel">
      <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalAdminAkun" onclick="resetForm()"><i class="bi bi-plus-lg"></i> Tambah Admin</button>
      </div>
      <div class="table-responsive">
        <table class="table align-middle table-hover">
          <thead><tr><th>Nama</th><th>Username</th><th>No. Telp</th><th>Alamat</th><th>Terdaftar</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($data) === 0): ?>
            <tr><td colspan="6" class="text-center text-muted">Belum ada data admin.</td></tr>
          <?php else: while ($p = mysqli_fetch_assoc($data)): ?>
            <tr>
              <td><?= htmlspecialchars($p['nama']) ?></td>
              <td><?= htmlspecialchars($p['username']) ?></td>
              <td><?= htmlspecialchars($p['no_telp']) ?></td>
              <td><?= htmlspecialchars($p['alamat']) ?></td>
              <td><?= formatTanggal($p['created_at']) ?></td>
              <td class="text-nowrap">
                <button class="btn btn-sm btn-outline-warning" onclick='editData(<?= json_encode($p) ?>)'><i class="bi bi-pencil"></i></button>
                <a class="btn btn-sm btn-outline-danger" href="?hapus=<?= $p['id'] ?>" onclick="return confirmDelete('Hapus admin ini?')"><i class="bi bi-trash"></i></a>
              </td>
            </tr>
          <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="modalAdminAkun" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST">
      <div class="modal-header"><h5 class="modal-title" id="modalTitle">Tambah Admin</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <input type="hidden" name="id" id="id">
        <div class="mb-2"><label class="form-label">Nama</label><input type="text" name="nama" id="nama" class="form-control" required></div>
        <div class="mb-2"><label class="form-label">Username</label><input type="text" name="username" id="username" class="form-control" required></div>
        <div class="mb-2"><label class="form-label">No. Telepon</label><input type="text" name="no_telp" id="no_telp" class="form-control"></div>
        <div class="mb-2"><label class="form-label">Alamat</label><textarea name="alamat" id="alamat" class="form-control" rows="2"></textarea></div>
        <div class="mb-2"><label class="form-label">Password <small class="text-muted">(kosongkan jika tidak diubah, default: admin123)</small></label><input type="password" name="password" id="password" class="form-control"></div>
      </div>
      <div class="modal-footer"><button type="submit" name="simpan" class="btn btn-primary w-100">Simpan</button></div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
function resetForm() {
  document.getElementById('modalTitle').innerText = 'Tambah Admin';
  document.querySelectorAll('#modalAdminAkun input, #modalAdminAkun textarea').forEach(i => i.value = '');
}
function editData(p) {
  document.getElementById('modalTitle').innerText = 'Edit Admin';
  document.getElementById('id').value = p.id;
  document.getElementById('nama').value = p.nama;
  document.getElementById('username').value = p.username;
  document.getElementById('no_telp').value = p.no_telp;
  document.getElementById('alamat').value = p.alamat;
  document.getElementById('password').value = '';
  new bootstrap.Modal(document.getElementById('modalAdminAkun')).show();
}
</script>
</body>
</html>
