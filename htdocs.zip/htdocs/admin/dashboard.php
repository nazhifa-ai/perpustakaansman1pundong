<?php
require_once "../config/db.php";
require_once "../config/functions.php";
requireRole('admin');
$pageTitle = "Dashboard Admin";

$loginNotif = $_SESSION['login_notif'] ?? '';
unset($_SESSION['login_notif']);

$totalBuku = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM buku"))['c'];
$totalSiswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM siswa"))['c'];
$totalDipinjam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi WHERE status='Dipinjam'"))['c'];
$totalTelat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM transaksi WHERE status='Dipinjam' AND tanggal_jatuh_tempo < CURDATE()"))['c'];

$transaksiTerbaru = mysqli_query($conn, "
  SELECT t.*, b.judul_buku, s.nama FROM transaksi t
  JOIN buku b ON b.id_buku=t.id_buku JOIN siswa s ON s.id_siswa=t.id_anggota
  ORDER BY t.id_transaksi DESC LIMIT 6
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body<?= $loginNotif ? ' data-login-notif="'.htmlspecialchars($loginNotif).'"' : '' ?>>
<div class="sb-wrapper">
  <?php include "includes/sidebar.php"; ?>
  <div class="content-area">
    <?php include "includes/header.php"; ?>

    <div class="row g-3 mb-3">
      <div class="col-6 col-lg-3">
        <div class="stat-card d-flex justify-content-between align-items-center">
          <div><div class="num"><?= $totalBuku ?></div><small class="text-muted">Judul Buku</small></div>
          <div class="icon-wrap" style="background:#2653a3;"><i class="bi bi-journal-bookmark"></i></div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card d-flex justify-content-between align-items-center">
          <div><div class="num"><?= $totalSiswa ?></div><small class="text-muted">Anggota Siswa</small></div>
          <div class="icon-wrap" style="background:#2a9d5c;"><i class="bi bi-people"></i></div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card d-flex justify-content-between align-items-center">
          <div><div class="num"><?= $totalDipinjam ?></div><small class="text-muted">Sedang Dipinjam</small></div>
          <div class="icon-wrap" style="background:#f4a52a;"><i class="bi bi-arrow-left-right"></i></div>
        </div>
      </div>
      <div class="col-6 col-lg-3">
        <div class="stat-card d-flex justify-content-between align-items-center">
          <div><div class="num text-danger"><?= $totalTelat ?></div><small class="text-muted">Terlambat</small></div>
          <div class="icon-wrap" style="background:#e0402c;"><i class="bi bi-exclamation-triangle"></i></div>
        </div>
      </div>
    </div>

    <?php if ($totalTelat > 0): ?>
    <div class="alert alert-warning d-flex align-items-center gap-2">
      <i class="bi bi-bell-fill fs-5"></i>
      <div><b><?= $totalTelat ?> peminjaman</b> telah melewati jatuh tempo. Cek menu Notifikasi di pojok kanan atas.</div>
    </div>
    <?php endif; ?>

    <div class="card-panel">
      <h6 class="fw-bold mb-3">Transaksi Terbaru</h6>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Siswa</th><th>Buku</th><th>Tgl Pinjam</th><th>Jatuh Tempo</th><th>Status</th></tr></thead>
          <tbody>
            <?php if (mysqli_num_rows($transaksiTerbaru) === 0): ?>
              <tr><td colspan="5" class="text-center text-muted">Belum ada transaksi.</td></tr>
            <?php else: while ($t = mysqli_fetch_assoc($transaksiTerbaru)): ?>
              <tr>
                <td><?= htmlspecialchars($t['nama']) ?></td>
                <td><?= htmlspecialchars($t['judul_buku']) ?></td>
                <td><?= formatTanggal($t['tanggal_pinjam']) ?></td>
                <td><?= formatTanggal($t['tanggal_jatuh_tempo']) ?></td>
                <td><?= badge($t['status']) ?></td>
              </tr>
            <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
</body>
</html>