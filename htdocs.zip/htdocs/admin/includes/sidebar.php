<?php $cur = basename($_SERVER['PHP_SELF']); ?>
<div class="sidebar" id="sidebarEl">
  <div class="brand" style="display: flex; align-items: center; gap: 10px; padding: 16px 12px;">
    <img src="../IMG/logo_sma.jpeg" alt="Logo SMAN 1 Pundong" style="height: 40px; width: 40px; object-fit: contain; border-radius: 4px; flex-shrink: 0;">
    <span style="font-size: 15px; font-weight: 600; line-height: 1.3;">Perpustakaan<br>SMAN 1 Pundong</span>
  </div>

  <div class="level-badge" style="margin: 0 12px 12px; padding: 8px 12px; background: rgba(255,255,255,.1); border-radius: 6px; display: flex; align-items: center; gap: 8px; font-size: 13px; color: #fff;">
    <i class="bi bi-person-badge"></i>
    <span> <strong>Admin</strong></span>
  </div>

  <nav class="nav flex-column py-2">
    <a class="nav-link <?= $cur=='dashboard.php'?'active':'' ?>" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a class="nav-link <?= $cur=='data_buku.php'?'active':'' ?>" href="data_buku.php"><i class="bi bi-journal-bookmark"></i> Data Buku</a>
    <a class="nav-link <?= $cur=='data_anggota.php'?'active':'' ?>" href="data_anggota.php"><i class="bi bi-people"></i> Data Anggota</a>
    <a class="nav-link <?= $cur=='petugas.php'?'active':'' ?>" href="petugas.php"><i class="bi bi-person-workspace"></i> Petugas</a>
    <a class="nav-link <?= $cur=='admin.php'?'active':'' ?>" href="admin.php"><i class="bi bi-person-badge"></i> Admin</a>
    <a class="nav-link <?= $cur=='transaksi.php'?'active':'' ?>" href="transaksi.php"><i class="bi bi-arrow-left-right"></i> Transaksi</a>
    <a class="nav-link <?= $cur=='pengembalian.php'?'active':'' ?>" href="pengembalian.php"><i class="bi bi-box-arrow-in-left"></i> Pengembalian</a>
    <a class="nav-link <?= $cur=='laporan.php'?'active':'' ?>" href="laporan.php"><i class="bi bi-graph-up"></i> Laporan</a>
    <hr class="mx-3" style="border-color: rgba(255,255,255,.15);">
    <a class="nav-link" href="logout.php" onclick="return confirmDelete('Yakin ingin logout?')"><i class="bi bi-box-arrow-right"></i> Logout</a>
  </nav>
</div>