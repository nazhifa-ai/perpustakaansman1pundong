<?php
// $pageTitle harus di-set sebelum include file ini
// Data notifikasi: transaksi yang sudah lewat jatuh tempo dan masih 'Dipinjam'
$notifQ = mysqli_query($conn, "
  SELECT t.id_transaksi, t.tanggal_jatuh_tempo, b.judul_buku, s.nama, DATEDIFF(CURDATE(), t.tanggal_jatuh_tempo) AS telat
  FROM transaksi t
  JOIN buku b ON b.id_buku = t.id_buku
  JOIN siswa s ON s.id_siswa = t.id_anggota
  WHERE t.status = 'Dipinjam' AND t.tanggal_jatuh_tempo < CURDATE()
  ORDER BY t.tanggal_jatuh_tempo ASC
");
$notifList = [];
while ($notifQ && ($row = mysqli_fetch_assoc($notifQ))) $notifList[] = $row;
$notifCount = count($notifList);
?>
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn btn-sm btn-light d-md-none" onclick="toggleSidebar()"><i class="bi bi-list"></i></button>
    <h5 class="mb-0 fw-bold"><?= $pageTitle ?? 'Dashboard' ?></h5>
  </div>
  <div class="d-flex align-items-center gap-3">
    <div class="dropdown">
      <span class="notif-bell" data-bs-toggle="dropdown" id="notifSoundTrigger" data-count="<?= $notifCount ?>">
        <i class="bi bi-bell fs-5"></i>
        <?php if ($notifCount > 0): ?><span class="dot"></span><?php endif; ?>
      </span>
      <div class="dropdown-menu dropdown-menu-end notif-dropdown p-2">
        <h6 class="dropdown-header">Notifikasi (<?= $notifCount ?>)</h6>
        <?php if ($notifCount === 0): ?>
          <p class="text-muted small px-2">Tidak ada peminjaman terlambat.</p>
        <?php else: foreach ($notifList as $n): ?>
          <div class="dropdown-item small border-bottom py-2">
            <b><?= htmlspecialchars($n['nama']) ?></b> terlambat mengembalikan<br>
            <span class="text-muted"><?= htmlspecialchars($n['judul_buku']) ?> &middot; <?= $n['telat'] ?> hari</span>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
    <div class="d-flex align-items-center gap-2">
      <div class="bg-light rounded-circle d-flex align-items-center justify-content-center" style="width:36px;height:36px;">
        <i class="bi bi-person-fill text-primary"></i>
      </div>
      <span class="fw-semibold small d-none d-sm-inline"><?= htmlspecialchars($_SESSION['nama'] ?? '') ?></span>
    </div>
  </div>
</div>
