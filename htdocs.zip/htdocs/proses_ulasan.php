<?php
require_once "config/db.php";
require_once "config/functions.php";
requireRole('siswa');

$id_buku  = (int)($_POST['id_buku'] ?? 0);
$rating   = (int)($_POST['rating'] ?? 0);
$komentar = clean($conn, $_POST['komentar'] ?? '');
$id_siswa = (int)$_SESSION['id'];

if ($id_buku <= 0 || $rating < 1 || $rating > 5) {
    $_SESSION['ulasan_error'] = "Data ulasan tidak lengkap, coba lagi.";
    header("Location: index.php#kategori");
    exit;
}

// Cek apakah siswa ini sudah pernah mengulas buku ini -> update, kalau belum -> insert baru
$cek = mysqli_prepare($conn, "SELECT id_ulasan FROM ulasan WHERE id_buku=? AND id_siswa=? LIMIT 1");
mysqli_stmt_bind_param($cek, "ii", $id_buku, $id_siswa);
mysqli_stmt_execute($cek);
$row = mysqli_stmt_get_result($cek)->fetch_assoc();

if ($row) {
    $stmt = mysqli_prepare($conn, "UPDATE ulasan SET rating=?, komentar=?, tanggal=NOW() WHERE id_ulasan=?");
    mysqli_stmt_bind_param($stmt, "isi", $rating, $komentar, $row['id_ulasan']);
} else {
    $stmt = mysqli_prepare($conn, "INSERT INTO ulasan (id_buku, id_siswa, rating, komentar) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "iiis", $id_buku, $id_siswa, $rating, $komentar);
}
mysqli_stmt_execute($stmt);

$_SESSION['ulasan_sukses'] = "Terima kasih! Ulasanmu berhasil disimpan.";
header("Location: index.php#kategori");
exit;