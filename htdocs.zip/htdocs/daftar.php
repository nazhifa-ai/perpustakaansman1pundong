<?php
require_once "config/db.php";
require_once "config/functions.php";

$error = ""; $success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nisn     = clean($conn, $_POST['nisn']);
    $nama     = clean($conn, $_POST['nama']);
    $kelas    = clean($conn, $_POST['kelas']);
    $jurusan  = clean($conn, $_POST['jurusan']);
    $no_telp  = clean($conn, $_POST['no_telp']);
    $alamat   = clean($conn, $_POST['alamat']);
    $username = clean($conn, $_POST['username']);
    $password = $_POST['password'];

    if ($nisn===''||$nama===''||$username===''||$password==='') {
        $error = "Lengkapi semua kolom wajib.";
    } else {
        $cek = mysqli_query($conn, "SELECT id_siswa FROM siswa WHERE nisn='$nisn' OR username='$username'");
        if (mysqli_num_rows($cek) > 0) {
            $error = "NISN atau username sudah terdaftar.";
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = mysqli_prepare($conn, "INSERT INTO siswa (nisn, nama, username, password, kelas, jurusan, no_telp, alamat) VALUES (?,?,?,?,?,?,?,?)");
            mysqli_stmt_bind_param($stmt, "ssssssss", $nisn, $nama, $username, $hash, $kelas, $jurusan, $no_telp, $alamat);
            if (mysqli_stmt_execute($stmt)) {
                $success = "Pendaftaran berhasil! Silakan login.";
            } else {
                $error = "Gagal mendaftar, coba lagi.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Daftar Anggota - Perpustakaan Sekolah Digital</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="login-wrapper">
  <div class="login-card" style="max-width:560px;">
    <div class="text-center pt-4">
      <i class="bi bi-person-plus-fill" style="font-size:36px;color:var(--brand);"></i>
      <h5 class="fw-bold mt-2">Daftar Anggota Siswa</h5>
    </div>
    <div class="p-4">
      <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <?php if ($success): ?><div class="alert alert-success py-2 small"><?= htmlspecialchars($success) ?> <a href="login.php?role=siswa">Login sekarang</a></div><?php endif; ?>
      <form method="POST">
        <div class="row g-2">
          <div class="col-6"><label class="form-label">NISN</label><input type="text" name="nisn" class="form-control" required></div>
          <div class="col-6"><label class="form-label">Nama Lengkap</label><input type="text" name="nama" class="form-control" required></div>
          <div class="col-6"><label class="form-label">Kelas</label><input type="text" name="kelas" class="form-control" placeholder="XII"></div>
          <div class="col-6"><label class="form-label">Jurusan</label><input type="text" name="jurusan" class="form-control" placeholder="RPL"></div>
          <div class="col-6"><label class="form-label">No. Telepon</label><input type="text" name="no_telp" class="form-control"></div>
          <div class="col-6"><label class="form-label">Username</label><input type="text" name="username" class="form-control" required></div>
          <div class="col-12"><label class="form-label">Alamat</label><textarea name="alamat" class="form-control" rows="2"></textarea></div>
          <div class="col-12"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
        </div>
        <button type="submit" class="btn w-100 text-white mt-3" style="background:var(--brand);">Daftar</button>
        <p class="text-center small mt-3 mb-0">Sudah punya akun? <a href="login.php?role=siswa">Login di sini</a></p>
      </form>
    </div>
  </div>
</div>
</body>
</html>
